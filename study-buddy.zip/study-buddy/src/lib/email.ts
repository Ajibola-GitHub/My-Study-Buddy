// src/lib/email.ts
// Email sending utilities using Nodemailer

import nodemailer from 'nodemailer'

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: Number(process.env.EMAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
})

interface EmailOptions {
  to: string
  subject: string
  html: string
}

async function sendEmail({ to, subject, html }: EmailOptions) {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'My Study Buddy <noreply@studybuddy.ng>',
    to,
    subject,
    html,
  })
}

/** Send password reset email */
export async function sendPasswordResetEmail(
  email: string,
  fullName: string,
  resetUrl: string
): Promise<void> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #1a5fb4, #3584e4); color: white; padding: 40px 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 24px; }
        .body { padding: 30px; }
        .button { display: inline-block; background: #1a5fb4; color: white; padding: 14px 30px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 20px 0; }
        .footer { background: #f8f9fa; padding: 20px 30px; text-align: center; color: #666; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>📚 My Study Buddy</h1>
          <p>Password Reset Request</p>
        </div>
        <div class="body">
          <h2>Hello, ${fullName}!</h2>
          <p>We received a request to reset your password for your Study Buddy account.</p>
          <p>Click the button below to create a new password. This link expires in <strong>1 hour</strong>.</p>
          <a href="${resetUrl}" class="button">Reset My Password</a>
          <p>If you didn't request this, you can safely ignore this email. Your password will remain unchanged.</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
          <p style="color: #666; font-size: 14px;">If the button doesn't work, copy this link:<br>
          <a href="${resetUrl}" style="color: #1a5fb4;">${resetUrl}</a></p>
        </div>
        <div class="footer">
          <p>My Study Buddy — Helping Nigerian students ace WAEC, NECO & JAMB</p>
          <p>© ${new Date().getFullYear()} Study Buddy. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `

  await sendEmail({
    to: email,
    subject: 'Reset Your Study Buddy Password',
    html,
  })
}

/** Send welcome email to new students */
export async function sendWelcomeEmail(email: string, fullName: string): Promise<void> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #1a5fb4, #3584e4); color: white; padding: 40px 30px; text-align: center; }
        .feature { display: flex; align-items: center; gap: 12px; margin: 16px 0; }
        .button { display: inline-block; background: #1a5fb4; color: white; padding: 14px 30px; border-radius: 8px; text-decoration: none; font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎉 Welcome to Study Buddy!</h1>
          <p>Your journey to exam success starts now</p>
        </div>
        <div style="padding: 30px;">
          <h2>Hello, ${fullName}!</h2>
          <p>Welcome to My Study Buddy — your personal AI-powered tutor for WAEC, NECO, and JAMB success!</p>
          
          <h3>Here's what you can do:</h3>
          <div class="feature">📚 <span>Practice thousands of past exam questions</span></div>
          <div class="feature">🤖 <span>Ask your AI tutor any question, anytime</span></div>
          <div class="feature">📊 <span>Track your progress across all subjects</span></div>
          <div class="feature">🔥 <span>Build study streaks to stay consistent</span></div>
          
          <p style="text-align: center; margin: 30px 0;">
            <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" class="button">
              Go to My Dashboard →
            </a>
          </p>
          
          <p>Remember: <strong>Consistent practice is the key to success!</strong> We believe in you. 💪</p>
        </div>
        <div style="background: #f8f9fa; padding: 20px 30px; text-align: center; color: #666; font-size: 14px;">
          <p>My Study Buddy — Made for Nigerian Students, by Nigerians</p>
        </div>
      </div>
    </body>
    </html>
  `

  await sendEmail({
    to: email,
    subject: '🎉 Welcome to My Study Buddy!',
    html,
  })
}
