// src/lib/utils.ts
// Shared utility functions

import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

/** Merge Tailwind CSS classes safely */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Format a number as percentage */
export function toPercent(value: number, total: number): number {
  if (total === 0) return 0
  return Math.round((value / total) * 100)
}

/** Format date as "2 hours ago", "yesterday", etc. */
export function timeAgo(date: Date | string): string {
  const d = new Date(date)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days === 1) return 'yesterday'
  if (days < 7) return `${days} days ago`
  return d.toLocaleDateString('en-NG', { day: 'numeric', month: 'short' })
}

/** Format duration in seconds to "5m 30s" */
export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return s > 0 ? `${m}m ${s}s` : `${m}m`
}

/** Generate a slug from a string */
export function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

/** Get difficulty badge color */
export function getDifficultyColor(difficulty: string): string {
  const colors: Record<string, string> = {
    EASY: 'bg-emerald-100 text-emerald-700',
    MEDIUM: 'bg-amber-100 text-amber-700',
    HARD: 'bg-red-100 text-red-700',
  }
  return colors[difficulty] || 'bg-gray-100 text-gray-700'
}

/** Get exam type badge color */
export function getExamTypeColor(examType: string): string {
  const colors: Record<string, string> = {
    WAEC: 'bg-blue-100 text-blue-700',
    NECO: 'bg-purple-100 text-purple-700',
    JAMB: 'bg-orange-100 text-orange-700',
    ALL: 'bg-gray-100 text-gray-700',
  }
  return colors[examType] || 'bg-gray-100 text-gray-700'
}

/** Get score grade and emoji */
export function getScoreGrade(percentage: number): { grade: string; emoji: string; color: string } {
  if (percentage >= 80) return { grade: 'Excellent', emoji: '🎉', color: 'text-emerald-600' }
  if (percentage >= 65) return { grade: 'Good', emoji: '👍', color: 'text-blue-600' }
  if (percentage >= 50) return { grade: 'Pass', emoji: '✅', color: 'text-amber-600' }
  return { grade: 'Needs Work', emoji: '📚', color: 'text-red-600' }
}

/** Shuffle an array (Fisher-Yates) */
export function shuffle<T>(array: T[]): T[] {
  const arr = [...array]
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr
}

/** Validate email format */
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

/** Generate a random token */
export function generateToken(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}
