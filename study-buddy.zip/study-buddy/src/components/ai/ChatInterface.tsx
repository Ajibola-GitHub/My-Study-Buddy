// src/components/ai/ChatInterface.tsx
// Full AI tutor chat interface with message history

'use client'

import { useState, useRef, useEffect } from 'react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Send, Bot, User, Paperclip, Loader2, Sparkles } from 'lucide-react'
import { timeAgo } from '@/lib/utils'

interface Message {
  id: string
  role: 'USER' | 'ASSISTANT'
  content: string
  imageUrl?: string | null
  createdAt: Date
}

interface ChatInterfaceProps {
  chatId?: string
  initialMessages?: Message[]
  subjectContext?: string
  examType?: string
}

const SUGGESTED_QUESTIONS = [
  'Explain photosynthesis in simple terms',
  'How do I solve quadratic equations?',
  'What is the difference between WAEC and JAMB?',
  'Explain the causes of World War II',
  'How does Newton\'s law of motion work?',
]

export function ChatInterface({
  chatId: initialChatId,
  initialMessages = [],
  subjectContext,
  examType,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState('')
  const [chatId, setChatId] = useState(initialChatId)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  // Auto scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  // Auto resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px'
    }
  }, [input])

  const sendMessage = async (content: string) => {
    if (!content.trim() || loading) return

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'USER',
      content,
      createdAt: new Date(),
    }

    setMessages((prev) => [...prev, userMsg])
    setInput('')
    setLoading(true)
    setError(null)

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId,
          content,
          subjectContext,
          examType,
        }),
      })

      const data = await res.json()

      if (!data.success) throw new Error(data.error)

      if (!chatId) setChatId(data.data.chatId)

      const aiMsg: Message = {
        id: Date.now().toString() + '_ai',
        role: 'ASSISTANT',
        content: data.data.content,
        createdAt: new Date(),
      }

      setMessages((prev) => [...prev, aiMsg])
    } catch (err: any) {
      setError(err.message || 'Failed to get response. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage(input)
    }
  }

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100 bg-gradient-to-r from-brand-50 to-blue-50">
        <div className="w-9 h-9 rounded-xl bg-brand-gradient flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="font-display font-semibold text-gray-900">Study Buddy AI</p>
          <p className="text-xs text-gray-500">
            {subjectContext ? `${subjectContext} Tutor` : 'Your personal tutor'} · Always here to help
          </p>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-gray-500">Online</span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center py-8">
            <div className="w-16 h-16 rounded-2xl bg-brand-gradient flex items-center justify-center text-3xl mb-4">
              🤖
            </div>
            <h3 className="font-display font-bold text-gray-800 text-lg mb-2">
              Hello! I'm your Study Buddy!
            </h3>
            <p className="text-gray-500 text-sm max-w-sm mb-6">
              Ask me anything about your subjects. I'm here to help you understand concepts, solve problems, and prepare for WAEC, NECO, and JAMB.
            </p>
            <div className="space-y-2 w-full max-w-sm">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Suggested Questions</p>
              {SUGGESTED_QUESTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => sendMessage(q)}
                  className="w-full text-left px-4 py-2.5 rounded-xl bg-surface-100 hover:bg-brand-50 hover:text-brand-700 text-sm text-gray-700 transition-colors border border-gray-100 hover:border-brand-100"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={cn(
              'flex gap-3 animate-slide-up',
              msg.role === 'USER' ? 'flex-row-reverse' : 'flex-row'
            )}
          >
            {/* Avatar */}
            <div className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-sm',
              msg.role === 'USER'
                ? 'bg-brand-100 text-brand-700 font-bold'
                : 'bg-brand-gradient text-white'
            )}>
              {msg.role === 'USER' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            {/* Bubble */}
            <div className={cn(
              'max-w-[80%] rounded-2xl px-4 py-3',
              msg.role === 'USER'
                ? 'bg-brand-600 text-white rounded-tr-sm'
                : 'bg-surface-100 text-gray-800 rounded-tl-sm'
            )}>
              {msg.imageUrl && (
                <img src={msg.imageUrl} alt="Uploaded" className="w-full max-h-48 object-contain rounded-xl mb-2" />
              )}
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
              <p className={cn('text-xs mt-1.5', msg.role === 'USER' ? 'text-brand-200' : 'text-gray-400')}>
                {timeAgo(msg.createdAt)}
              </p>
            </div>
          </div>
        ))}

        {/* Loading indicator */}
        {loading && (
          <div className="flex gap-3 animate-fade-in">
            <div className="w-8 h-8 rounded-full bg-brand-gradient flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-surface-100 rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-xl border border-red-100">
            ⚠️ {error}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-100 bg-surface-50">
        <div className="flex items-end gap-2">
          <div className="flex-1 bg-white border border-gray-200 rounded-2xl overflow-hidden focus-within:border-brand-400 focus-within:ring-2 focus-within:ring-brand-100 transition-all">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask me anything... (Press Enter to send)"
              rows={1}
              className="w-full px-4 py-3 text-sm resize-none focus:outline-none bg-transparent max-h-32"
              disabled={loading}
            />
          </div>
          <Button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
            size="icon"
            className="shrink-0 w-11 h-11 rounded-xl"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
        <p className="text-xs text-gray-400 mt-2 text-center">
          AI can make mistakes. Verify important information from your textbooks.
        </p>
      </div>
    </div>
  )
}
