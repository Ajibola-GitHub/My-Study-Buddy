// src/components/layout/Sidebar.tsx
// Left sidebar navigation for authenticated students

'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { signOut } from 'next-auth/react'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, BookOpen, Brain, BarChart3, User, LogOut,
  Flame, ChevronRight, GraduationCap, MessageSquare,
} from 'lucide-react'

interface SidebarProps {
  user: {
    fullName: string
    email: string
    examType: string
    studyStreak?: number
    image?: string | null
  }
}

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/subjects', label: 'Subjects', icon: BookOpen },
  { href: '/practice', label: 'Practice', icon: GraduationCap },
  { href: '/ai-tutor', label: 'AI Tutor', icon: Brain },
  { href: '/profile', label: 'Profile', icon: User },
]

export function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname()

  return (
    <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-white border-r border-gray-100 fixed left-0 top-0">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-gray-100">
        <div className="w-9 h-9 rounded-xl bg-brand-gradient flex items-center justify-center text-white text-lg">
          📚
        </div>
        <div>
          <p className="font-display font-bold text-gray-900 leading-none">Study Buddy</p>
          <p className="text-xs text-gray-500 mt-0.5">{user.examType} Prep</p>
        </div>
      </div>

      {/* Study Streak Banner */}
      {(user.studyStreak || 0) > 0 && (
        <div className="mx-4 mt-4 bg-gradient-to-r from-orange-50 to-red-50 border border-orange-100 rounded-xl px-3 py-2.5 flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-500" />
          <span className="text-sm font-semibold text-orange-700">
            {user.studyStreak} day streak! 🔥
          </span>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/')

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group',
                isActive
                  ? 'bg-brand-50 text-brand-700 shadow-sm'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              )}
            >
              <Icon className={cn('w-5 h-5 shrink-0 transition-colors', isActive ? 'text-brand-600' : 'text-gray-400 group-hover:text-gray-600')} />
              {item.label}
              {isActive && <ChevronRight className="w-4 h-4 ml-auto text-brand-400" />}
            </Link>
          )
        })}
      </nav>

      {/* User profile + logout */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex items-center gap-3 px-2 mb-3">
          <div className="w-9 h-9 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-sm shrink-0">
            {user.fullName.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 truncate">{user.fullName}</p>
            <p className="text-xs text-gray-500 truncate">{user.email}</p>
          </div>
        </div>
        <button
          onClick={() => signOut({ callbackUrl: '/login' })}
          className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors font-medium"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  )
}

// ── Mobile Bottom Navigation ──────────────────────────────────

export function MobileNav() {
  const pathname = usePathname()

  const mobileItems = [
    { href: '/dashboard', label: 'Home', icon: LayoutDashboard },
    { href: '/subjects', label: 'Subjects', icon: BookOpen },
    { href: '/practice', label: 'Practice', icon: GraduationCap },
    { href: '/ai-tutor', label: 'AI', icon: Brain },
    { href: '/profile', label: 'Me', icon: User },
  ]

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 z-50 pb-safe">
      <div className="flex items-center justify-around py-2">
        {mobileItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/')

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-all',
                isActive ? 'text-brand-600' : 'text-gray-400'
              )}
            >
              <Icon className={cn('w-5 h-5', isActive && 'fill-brand-100')} />
              <span className={cn('text-[10px] font-medium', isActive ? 'text-brand-600' : 'text-gray-400')}>
                {item.label}
              </span>
              {isActive && <div className="w-1 h-1 rounded-full bg-brand-500" />}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
