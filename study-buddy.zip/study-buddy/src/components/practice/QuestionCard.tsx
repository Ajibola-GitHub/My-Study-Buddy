// src/components/practice/QuestionCard.tsx
// Multiple-choice question with instant feedback

'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import { getDifficultyColor, getExamTypeColor } from '@/lib/utils'
import { CheckCircle2, XCircle, Lightbulb, ChevronRight } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import type { Question } from '@/types'

interface QuestionCardProps {
  question: Question
  questionNumber: number
  total: number
  onAnswer: (questionId: string, optionId: string) => Promise<{
    isCorrect: boolean
    correctOptionId: string
    explanation: string
  }>
  onNext: () => void
  isLast?: boolean
}

export function QuestionCard({
  question,
  questionNumber,
  total,
  onAnswer,
  onNext,
  isLast,
}: QuestionCardProps) {
  const [selected, setSelected] = useState<string | null>(null)
  const [result, setResult] = useState<{
    isCorrect: boolean
    correctOptionId: string
    explanation: string
  } | null>(null)
  const [loading, setLoading] = useState(false)
  const [startTime] = useState(Date.now())

  const handleSelect = async (optionId: string) => {
    if (selected || loading) return
    setSelected(optionId)
    setLoading(true)

    const timeTaken = Math.round((Date.now() - startTime) / 1000)

    try {
      const res = await onAnswer(question.id, optionId)
      setResult(res)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const getOptionStyle = (optionId: string) => {
    if (!result) {
      return selected === optionId
        ? 'border-brand-400 bg-brand-50 text-brand-800'
        : 'border-gray-100 hover:border-brand-200 hover:bg-brand-50 cursor-pointer'
    }
    if (optionId === result.correctOptionId) return 'border-emerald-400 bg-emerald-50 text-emerald-800'
    if (optionId === selected && !result.isCorrect) return 'border-red-400 bg-red-50 text-red-800'
    return 'border-gray-100 opacity-50'
  }

  const handleNext = () => {
    setSelected(null)
    setResult(null)
    onNext()
  }

  return (
    <div className="animate-fade-in">
      {/* Progress */}
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-gray-500 font-medium">
          Question {questionNumber} of {total}
        </span>
        <div className="flex gap-1.5">
          <Badge className={getDifficultyColor(question.difficulty)} variant="secondary">
            {question.difficulty}
          </Badge>
          <Badge className={getExamTypeColor(question.examType)} variant="secondary">
            {question.examType}
          </Badge>
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden mb-6">
        <div
          className="h-full bg-brand-500 rounded-full transition-all duration-500"
          style={{ width: `${(questionNumber / total) * 100}%` }}
        />
      </div>

      {/* Question */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-4">
        <div className="flex items-center gap-2 mb-3">
          {question.subject && (
            <span className="text-xs font-medium text-gray-500">
              {question.subject.name}
              {question.topic && ` · ${question.topic.name}`}
            </span>
          )}
        </div>

        {question.imageUrl && (
          <img
            src={question.imageUrl}
            alt="Question diagram"
            className="w-full max-h-48 object-contain rounded-xl mb-4 bg-gray-50"
          />
        )}

        <p className="text-gray-900 font-medium text-base leading-relaxed">
          {question.text}
        </p>
      </div>

      {/* Options */}
      <div className="space-y-3 mb-4">
        {question.options.map((option) => (
          <button
            key={option.id}
            onClick={() => handleSelect(option.id)}
            disabled={!!selected || loading}
            className={cn(
              'w-full flex items-center gap-4 p-4 rounded-xl border-2 text-left transition-all duration-150 font-medium text-sm',
              getOptionStyle(option.id)
            )}
          >
            {/* Option label */}
            <span className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0',
              result?.correctOptionId === option.id
                ? 'bg-emerald-500 text-white'
                : selected === option.id && result && !result.isCorrect
                ? 'bg-red-500 text-white'
                : 'bg-gray-100 text-gray-600'
            )}>
              {option.label}
            </span>
            <span className="flex-1">{option.text}</span>

            {/* Result icon */}
            {result && option.id === result.correctOptionId && (
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
            )}
            {result && option.id === selected && !result.isCorrect && (
              <XCircle className="w-5 h-5 text-red-500 shrink-0" />
            )}
          </button>
        ))}
      </div>

      {/* Result feedback */}
      {result && (
        <div className={cn(
          'rounded-2xl p-5 mb-4 animate-slide-up border',
          result.isCorrect
            ? 'bg-emerald-50 border-emerald-100'
            : 'bg-amber-50 border-amber-100'
        )}>
          <div className="flex items-center gap-2 mb-2">
            {result.isCorrect ? (
              <><CheckCircle2 className="w-5 h-5 text-emerald-600" /><span className="font-bold text-emerald-700">Excellent! Correct! 🎉</span></>
            ) : (
              <><XCircle className="w-5 h-5 text-red-600" /><span className="font-bold text-amber-700">Not quite — but you'll get it! 💪</span></>
            )}
          </div>
          <div className="flex gap-2 mt-3">
            <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-gray-600 mb-1">Explanation:</p>
              <p className="text-sm text-gray-700 whitespace-pre-line">{result.explanation}</p>
            </div>
          </div>
        </div>
      )}

      {/* Next button */}
      {result && (
        <Button onClick={handleNext} className="w-full" size="lg">
          {isLast ? 'See Results 🏆' : 'Next Question'}
          <ChevronRight className="w-4 h-4" />
        </Button>
      )}
    </div>
  )
}
