// src/components/subjects/SubjectCard.tsx
// Displays a single subject with progress and enroll/open CTA

'use client'

import Link from 'next/link'
import { cn } from '@/lib/utils'
import { BookOpen, ChevronRight, CheckCircle2 } from 'lucide-react'
import type { Subject } from '@/types'

interface SubjectCardProps {
  subject: Subject
  isEnrolled?: boolean
  questionCount?: number
  topicCount?: number
  accuracy?: number
  onEnroll?: (subjectId: string) => void
  enrolling?: boolean
}

export function SubjectCard({
  subject,
  isEnrolled,
  accuracy,
  onEnroll,
  enrolling,
}: SubjectCardProps) {
  const topicCount = subject._count?.topics || 0
  const questionCount = subject._count?.questions || 0

  return (
    <div
      className={cn(
        'bg-white rounded-2xl border shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md hover:-translate-y-0.5',
        isEnrolled ? 'border-brand-100' : 'border-gray-100'
      )}
    >
      {/* Color stripe */}
      <div
        className="h-1.5 w-full"
        style={{ backgroundColor: subject.color || '#3468FF' }}
      />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
            style={{ backgroundColor: `${subject.color}18` || '#3468FF18' }}
          >
            {subject.icon || '📚'}
          </div>
          {isEnrolled && (
            <span className="flex items-center gap-1 text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              <CheckCircle2 className="w-3 h-3" />
              Enrolled
            </span>
          )}
        </div>

        {/* Name & desc */}
        <h3 className="font-display font-semibold text-gray-900 text-base">{subject.name}</h3>
        {subject.description && (
          <p className="text-xs text-gray-500 mt-1 line-clamp-2">{subject.description}</p>
        )}

        {/* Stats */}
        <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5" />
            {topicCount} topics
          </span>
          <span>•</span>
          <span>{questionCount} questions</span>
          {subject.examTypes.length > 0 && (
            <>
              <span>•</span>
              <span className="text-brand-600 font-medium">{subject.examTypes.slice(0,2).join(', ')}</span>
            </>
          )}
        </div>

        {/* Accuracy bar (if enrolled and has data) */}
        {isEnrolled && accuracy !== undefined && (
          <div className="mt-3">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-gray-500">Accuracy</span>
              <span className="font-semibold text-gray-700">{accuracy}%</span>
            </div>
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${accuracy}%`,
                  backgroundColor: accuracy >= 70 ? '#10B981' : accuracy >= 50 ? '#F59E0B' : '#EF4444',
                }}
              />
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="mt-4">
          {isEnrolled ? (
            <Link
              href={`/subjects/${subject.slug}`}
              className="flex items-center justify-between w-full px-4 py-2.5 bg-brand-50 text-brand-700 rounded-xl text-sm font-semibold hover:bg-brand-100 transition-colors"
            >
              Continue Studying
              <ChevronRight className="w-4 h-4" />
            </Link>
          ) : (
            <button
              onClick={() => onEnroll?.(subject.id)}
              disabled={enrolling}
              className="w-full px-4 py-2.5 bg-gray-50 text-gray-700 rounded-xl text-sm font-semibold hover:bg-brand-50 hover:text-brand-700 transition-colors border border-gray-100 disabled:opacity-50"
            >
              {enrolling ? 'Enrolling...' : 'Enroll Now'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
