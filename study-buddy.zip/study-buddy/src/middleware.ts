// src/middleware.ts
// Protect student and admin routes

import { auth } from '@/lib/auth'
import { NextResponse } from 'next/server'

export default auth((req) => {
  const { pathname } = req.nextUrl
  const isLoggedIn = !!req.auth

  const protectedRoutes = ['/dashboard', '/subjects', '/practice', '/ai-tutor', '/profile']
  const adminRoutes = ['/admin']
  const authRoutes = ['/login', '/signup', '/forgot-password']

  const isProtected = protectedRoutes.some((r) => pathname.startsWith(r))
  const isAdmin = adminRoutes.some((r) => pathname.startsWith(r))
  const isAuth = authRoutes.some((r) => pathname.startsWith(r))

  if ((isProtected || isAdmin) && !isLoggedIn) {
    return NextResponse.redirect(new URL('/login', req.url))
  }

  if (isAdmin && req.auth?.user?.role === 'STUDENT') {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  if (isAuth && isLoggedIn) {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  return NextResponse.next()
})

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
}
