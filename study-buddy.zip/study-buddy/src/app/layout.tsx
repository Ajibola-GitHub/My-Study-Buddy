// src/app/layout.tsx
// Root layout - fonts, metadata, global providers

import type { Metadata, Viewport } from 'next'
import { Plus_Jakarta_Sans, Sora, JetBrains_Mono } from 'next/font/google'
import { Toaster } from '@/components/ui/toaster'
import './globals.css'

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-plus-jakarta',
  display: 'swap',
})

const sora = Sora({
  subsets: ['latin'],
  variable: '--font-sora',
  display: 'swap',
})

const jetBrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'My Study Buddy — Ace WAEC, NECO & JAMB',
    template: '%s | My Study Buddy',
  },
  description: 'AI-powered exam prep for Nigerian secondary school students. Practice questions, get personalized tutoring, and track your progress for WAEC, NECO and JAMB.',
  keywords: ['WAEC', 'NECO', 'JAMB', 'Nigerian students', 'exam prep', 'study app', 'secondary school'],
  authors: [{ name: 'My Study Buddy' }],
  creator: 'My Study Buddy',
  openGraph: {
    type: 'website',
    locale: 'en_NG',
    url: 'https://studybuddy.ng',
    title: 'My Study Buddy — Ace WAEC, NECO & JAMB',
    description: 'AI-powered exam prep for Nigerian secondary school students.',
    siteName: 'My Study Buddy',
  },
  robots: { index: true, follow: true },
  manifest: '/manifest.json',
  icons: { icon: '/favicon.ico', apple: '/apple-icon.png' },
}

export const viewport: Viewport = {
  themeColor: '#1A44F5',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${plusJakarta.variable} ${sora.variable} ${jetBrains.variable} font-sans antialiased`}>
        {children}
        <Toaster />
      </body>
    </html>
  )
}
