// src/app/page.tsx
// Public landing page

import Link from 'next/link'
import { CheckCircle2, Star, Brain, BookOpen, Trophy, Zap } from 'lucide-react'

export default function LandingPage() {
  const features = [
    { icon: '🤖', title: 'AI-Powered Tutor', desc: 'Get instant step-by-step explanations in simple Nigerian English, available 24/7' },
    { icon: '📝', title: 'Past Questions Bank', desc: 'Practice thousands of real WAEC, NECO and JAMB past questions with full explanations' },
    { icon: '📊', title: 'Track Your Progress', desc: 'Detailed analytics show your strengths and weaknesses across all subjects' },
    { icon: '🔥', title: 'Daily Study Streaks', desc: 'Build consistent study habits with streak tracking and daily challenges' },
    { icon: '📱', title: 'Mobile First', desc: 'Study anywhere on your phone — fully optimised for Android and iOS devices' },
    { icon: '🎯', title: 'Smart Recommendations', desc: 'AI identifies your weak areas and recommends exactly what to study next' },
  ]

  const subjects = ['Mathematics', 'English', 'Physics', 'Chemistry', 'Biology', 'Economics', 'Government', 'Commerce', 'CRS', 'Literature']

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-brand-gradient flex items-center justify-center text-white text-lg">📚</div>
            <span className="font-display font-bold text-gray-900">My Study Buddy</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm font-semibold text-gray-600 hover:text-gray-900">Sign In</Link>
            <Link href="/signup" className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700 transition-colors">
              Start Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative bg-gradient-to-br from-brand-950 via-brand-800 to-blue-600 text-white overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-1/4 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-5xl mx-auto px-6 py-24 text-center relative">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-2 text-sm mb-8">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span>Built for Nigerian Students — WAEC · NECO · JAMB</span>
          </div>
          <h1 className="font-display text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Your AI Tutor for<br />
            <span className="text-yellow-300">Exam Success</span>
          </h1>
          <p className="text-blue-100 text-lg md:text-xl max-w-2xl mx-auto mb-10">
            Practice thousands of past questions, get instant AI explanations, and track your progress — all in one app designed for Nigerian secondary school students.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup" className="px-8 py-4 bg-yellow-400 text-gray-900 rounded-2xl text-base font-bold hover:bg-yellow-300 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5">
              🚀 Start Studying Free
            </Link>
            <Link href="/login" className="px-8 py-4 bg-white/10 backdrop-blur text-white rounded-2xl text-base font-semibold hover:bg-white/20 transition-all border border-white/20">
              I have an account
            </Link>
          </div>
          <p className="mt-4 text-blue-200 text-sm">Free to use · No credit card required</p>
        </div>
      </section>

      {/* Subjects */}
      <section className="py-12 bg-surface-50 border-y border-gray-100">
        <div className="max-w-5xl mx-auto px-6">
          <p className="text-center text-sm font-semibold text-gray-500 uppercase tracking-wider mb-6">Covering All Major Subjects</p>
          <div className="flex flex-wrap justify-center gap-3">
            {subjects.map((s) => (
              <span key={s} className="px-4 py-2 bg-white rounded-full text-sm font-medium text-gray-700 border border-gray-200 shadow-sm">
                {s}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 max-w-6xl mx-auto px-6">
        <div className="text-center mb-14">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need to Pass
          </h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            My Study Buddy combines AI technology with proven study techniques tailored for Nigerian examinations.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
              <div className="text-3xl mb-4">{f.icon}</div>
              <h3 className="font-display font-semibold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-surface-50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-display text-3xl font-bold text-gray-900 mb-12">Start in 3 Simple Steps</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Create Free Account', desc: 'Sign up with your email, choose your class level and target exam (WAEC, NECO or JAMB)' },
              { step: '02', title: 'Pick Your Subjects', desc: 'Enroll in the subjects you want to master and start practicing past questions immediately' },
              { step: '03', title: 'Learn & Improve', desc: 'Use the AI tutor for help, track your scores, and watch your performance improve daily' },
            ].map((s) => (
              <div key={s.step} className="relative">
                <div className="w-12 h-12 rounded-2xl bg-brand-600 text-white font-display font-bold text-lg flex items-center justify-center mx-auto mb-4">
                  {s.step}
                </div>
                <h3 className="font-display font-semibold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 max-w-4xl mx-auto px-6 text-center">
        <div className="bg-gradient-to-br from-brand-600 to-blue-500 rounded-3xl p-12 text-white">
          <Trophy className="w-12 h-12 text-yellow-300 mx-auto mb-4" />
          <h2 className="font-display text-3xl font-bold mb-4">Ready to Ace Your Exams?</h2>
          <p className="text-blue-100 mb-8 max-w-xl mx-auto">
            Join thousands of Nigerian students already using My Study Buddy to prepare for WAEC, NECO, and JAMB.
          </p>
          <Link href="/signup" className="inline-flex items-center gap-2 px-8 py-4 bg-yellow-400 text-gray-900 rounded-2xl text-base font-bold hover:bg-yellow-300 transition-all">
            <Zap className="w-5 h-5" /> Get Started — It's Free!
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-100 py-8">
        <div className="max-w-6xl mx-auto px-6 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} My Study Buddy. Made with ❤️ for Nigerian Students.</p>
          <p className="mt-1">Supporting WAEC · NECO · JAMB preparation across Nigeria</p>
        </div>
      </footer>
    </div>
  )
}
