// src/app/api/auth/forgot-password/route.ts
// POST /api/auth/forgot-password - Send password reset email

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'
import { sendPasswordResetEmail } from '@/lib/email'
import { generateToken } from '@/lib/utils'

const schema = z.object({
  email: z.string().email(),
})

export async function POST(req: NextRequest) {
  try {
    const { email } = schema.parse(await req.json())

    const user = await db.user.findUnique({ where: { email } })

    // Always return success to prevent email enumeration
    if (!user) {
      return NextResponse.json({
        success: true,
        message: 'If an account exists, a reset email has been sent.',
      })
    }

    // Invalidate any existing tokens
    await db.passwordReset.updateMany({
      where: { userId: user.id, used: false },
      data: { used: true },
    })

    // Create new reset token (expires in 1 hour)
    const token = generateToken()
    await db.passwordReset.create({
      data: {
        userId: user.id,
        token,
        expires: new Date(Date.now() + 3600000), // 1 hour
      },
    })

    const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${token}`
    await sendPasswordResetEmail(user.email, user.fullName, resetUrl)

    return NextResponse.json({
      success: true,
      message: 'If an account exists, a reset email has been sent.',
    })
  } catch (error) {
    console.error('[FORGOT_PASSWORD_ERROR]', error)
    return NextResponse.json(
      { success: false, error: 'Something went wrong.' },
      { status: 500 }
    )
  }
}
