// src/app/api/auth/register/route.ts
// POST /api/auth/register - Create new student account

import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { z } from 'zod'
import { db } from '@/lib/db'
import { sendWelcomeEmail } from '@/lib/email'

const registerSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  classLevel: z.enum(['SS1', 'SS2', 'SS3']),
  examType: z.enum(['WAEC', 'NECO', 'JAMB']),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const data = registerSchema.parse(body)

    // Check if email is already taken
    const existingUser = await db.user.findUnique({
      where: { email: data.email },
    })

    if (existingUser) {
      return NextResponse.json(
        { success: false, error: 'An account with this email already exists' },
        { status: 400 }
      )
    }

    // Hash password
    const passwordHash = await bcrypt.hash(data.password, 12)

    // Create user
    const user = await db.user.create({
      data: {
        fullName: data.fullName,
        email: data.email,
        passwordHash,
        classLevel: data.classLevel,
        examType: data.examType,
        role: 'STUDENT',
      },
    })

    // Auto-enroll in 3 core subjects
    const coreSubjects = await db.subject.findMany({
      where: { slug: { in: ['mathematics', 'english', 'biology'] } },
      take: 3,
    })

    if (coreSubjects.length > 0) {
      await db.enrollment.createMany({
        data: coreSubjects.map((s) => ({ userId: user.id, subjectId: s.id })),
        skipDuplicates: true,
      })
    }

    // Send welcome email (fire and forget)
    sendWelcomeEmail(user.email, user.fullName).catch(console.error)

    return NextResponse.json({
      success: true,
      message: 'Account created successfully! Please log in.',
      data: { id: user.id, email: user.email },
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors[0].message },
        { status: 400 }
      )
    }
    console.error('[REGISTER_ERROR]', error)
    return NextResponse.json(
      { success: false, error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
