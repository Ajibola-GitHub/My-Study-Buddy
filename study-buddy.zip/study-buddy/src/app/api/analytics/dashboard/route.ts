// src/app/api/analytics/dashboard/route.ts
// GET /api/analytics/dashboard - Fetch dashboard statistics for current user

import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { subDays, startOfDay, format } from 'date-fns'

export async function GET(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const userId = session.user.id

    // Parallel queries for efficiency
    const [
      user,
      totalAttempts,
      correctAttempts,
      aiChatsCount,
      enrollmentsCount,
      subjectPerformance,
      recentAttempts,
      weeklyData,
    ] = await Promise.all([
      db.user.findUnique({ where: { id: userId }, select: { studyStreak: true, fullName: true } }),

      db.practiceAttempt.count({ where: { userId } }),

      db.practiceAttempt.count({ where: { userId, isCorrect: true } }),

      db.aIChat.count({ where: { userId } }),

      db.enrollment.count({ where: { userId } }),

      // Performance per subject
      db.practiceAttempt.groupBy({
        by: ['questionId'],
        where: { userId },
        _count: { _all: true },
      }).then(async (grouped) => {
        // Get subject-level breakdown
        const attempts = await db.practiceAttempt.findMany({
          where: { userId },
          include: {
            question: {
              include: { subject: { select: { id: true, name: true, color: true } } },
            },
          },
        })

        const bySubject: Record<string, { name: string; color: string; total: number; correct: number }> = {}
        for (const a of attempts) {
          const subj = a.question.subject
          if (!bySubject[subj.id]) {
            bySubject[subj.id] = { name: subj.name, color: subj.color || '#3B82F6', total: 0, correct: 0 }
          }
          bySubject[subj.id].total++
          if (a.isCorrect) bySubject[subj.id].correct++
        }

        return Object.entries(bySubject).map(([id, v]) => ({
          subjectId: id,
          subjectName: v.name,
          subjectColor: v.color,
          totalAttempts: v.total,
          correctAnswers: v.correct,
          percentage: v.total > 0 ? Math.round((v.correct / v.total) * 100) : 0,
        }))
      }),

      // Recent activity (last 10 attempts)
      db.practiceAttempt.findMany({
        where: { userId },
        include: { question: { include: { subject: { select: { name: true, icon: true } } } } },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),

      // Weekly progress (last 7 days)
      Promise.all(
        Array.from({ length: 7 }, (_, i) => {
          const date = startOfDay(subDays(new Date(), 6 - i))
          const nextDate = startOfDay(subDays(new Date(), 5 - i))
          return db.practiceAttempt
            .findMany({
              where: { userId, createdAt: { gte: date, lt: nextDate } },
              select: { isCorrect: true },
            })
            .then((attempts) => ({
              day: format(date, 'EEE'),
              attempts: attempts.length,
              correct: attempts.filter((a) => a.isCorrect).length,
            }))
        })
      ),
    ])

    // Build recent activity feed
    const recentActivity = recentAttempts.map((a) => ({
      id: a.id,
      type: 'practice' as const,
      description: `${a.isCorrect ? '✅ Correct' : '❌ Wrong'} answer in ${a.question.subject.icon} ${a.question.subject.name}`,
      timestamp: a.createdAt,
    }))

    return NextResponse.json({
      success: true,
      data: {
        totalAttempts,
        correctAnswers: correctAttempts,
        wrongAnswers: totalAttempts - correctAttempts,
        accuracy: totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0,
        studyStreak: user?.studyStreak || 0,
        aiChatsUsed: aiChatsCount,
        subjectsEnrolled: enrollmentsCount,
        recentActivity,
        subjectPerformance,
        weeklyProgress: weeklyData,
      },
    })
  } catch (error) {
    console.error('[ANALYTICS_DASHBOARD_ERROR]', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch analytics' }, { status: 500 })
  }
}
