// src/app/api/questions/route.ts
// GET /api/questions - List/filter questions
// POST /api/questions - Create question (admin)

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const subjectId = searchParams.get('subjectId')
    const topicId = searchParams.get('topicId')
    const examType = searchParams.get('examType')
    const difficulty = searchParams.get('difficulty')
    const limit = Number(searchParams.get('limit')) || 10
    const page = Number(searchParams.get('page')) || 1

    const where: any = { isActive: true }
    if (subjectId) where.subjectId = subjectId
    if (topicId) where.topicId = topicId
    if (examType) where.examType = { in: [examType, 'ALL'] }
    if (difficulty) where.difficulty = difficulty

    const [questions, total] = await Promise.all([
      db.question.findMany({
        where,
        include: {
          options: true,
          subject: { select: { name: true, slug: true, color: true } },
          topic: { select: { name: true, slug: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: (page - 1) * limit,
      }),
      db.question.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: questions,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    })
  } catch (error) {
    console.error('[QUESTIONS_GET_ERROR]', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch questions' }, { status: 500 })
  }
}

const optionSchema = z.object({
  label: z.enum(['A', 'B', 'C', 'D']),
  text: z.string().min(1),
  isCorrect: z.boolean(),
})

const createQuestionSchema = z.object({
  subjectId: z.string().cuid(),
  topicId: z.string().cuid().optional(),
  text: z.string().min(5),
  imageUrl: z.string().url().optional(),
  examType: z.enum(['WAEC', 'NECO', 'JAMB', 'ALL']),
  examYear: z.number().min(1990).max(2025).optional(),
  difficulty: z.enum(['EASY', 'MEDIUM', 'HARD']),
  explanation: z.string().min(10),
  options: z.array(optionSchema).length(4),
})

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const data = createQuestionSchema.parse(await req.json())

    // Ensure exactly one correct answer
    const correctCount = data.options.filter((o) => o.isCorrect).length
    if (correctCount !== 1) {
      return NextResponse.json(
        { success: false, error: 'Exactly one option must be marked as correct' },
        { status: 400 }
      )
    }

    const question = await db.question.create({
      data: {
        subjectId: data.subjectId,
        topicId: data.topicId,
        text: data.text,
        imageUrl: data.imageUrl,
        examType: data.examType,
        examYear: data.examYear,
        difficulty: data.difficulty,
        explanation: data.explanation,
        options: { create: data.options },
      },
      include: { options: true },
    })

    return NextResponse.json({ success: true, data: question }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    return NextResponse.json({ success: false, error: 'Failed to create question' }, { status: 500 })
  }
}
