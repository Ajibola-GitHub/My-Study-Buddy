// src/app/api/profile/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { z } from 'zod'

const schema = z.object({
  fullName: z.string().min(2).optional(),
  classLevel: z.enum(['SS1', 'SS2', 'SS3']).optional(),
  examType: z.enum(['WAEC', 'NECO', 'JAMB']).optional(),
})

export async function PATCH(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })

    const data = schema.parse(await req.json())
    const user = await db.user.update({ where: { id: session.user.id }, data })

    return NextResponse.json({ success: true, data: user })
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Update failed' }, { status: 500 })
  }
}
