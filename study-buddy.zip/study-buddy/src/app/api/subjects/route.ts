// src/app/api/subjects/route.ts
// GET /api/subjects - List all active subjects
// POST /api/subjects - Create a new subject (admin only)

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const examType = searchParams.get('examType')
    const enrolled = searchParams.get('enrolled')

    const session = await auth()

    let subjects

    if (enrolled === 'true' && session?.user?.id) {
      // Get subjects the user is enrolled in
      const enrollments = await db.enrollment.findMany({
        where: { userId: session.user.id },
        include: {
          subject: {
            include: {
              _count: { select: { topics: true, questions: true } },
            },
          },
        },
      })
      subjects = enrollments.map((e) => e.subject)
    } else {
      subjects = await db.subject.findMany({
        where: {
          isActive: true,
          ...(examType ? { examTypes: { has: examType as any } } : {}),
        },
        include: {
          _count: { select: { topics: true, questions: true } },
        },
        orderBy: { name: 'asc' },
      })
    }

    return NextResponse.json({ success: true, data: subjects })
  } catch (error) {
    console.error('[SUBJECTS_GET_ERROR]', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch subjects' }, { status: 500 })
  }
}

const createSubjectSchema = z.object({
  name: z.string().min(1),
  slug: z.string().min(1),
  description: z.string().optional(),
  icon: z.string().optional(),
  color: z.string().optional(),
  examTypes: z.array(z.enum(['WAEC', 'NECO', 'JAMB', 'ALL'])),
})

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session || session.user.role !== 'ADMIN') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const data = createSubjectSchema.parse(await req.json())
    const subject = await db.subject.create({ data })

    return NextResponse.json({ success: true, data: subject }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    return NextResponse.json({ success: false, error: 'Failed to create subject' }, { status: 500 })
  }
}
