// src/app/api/subjects/enroll/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })

    const { subjectId } = await req.json()
    if (!subjectId) return NextResponse.json({ success: false, error: 'subjectId required' }, { status: 400 })

    const enrollment = await db.enrollment.upsert({
      where: { userId_subjectId: { userId: session.user.id, subjectId } },
      update: {},
      create: { userId: session.user.id, subjectId },
    })

    return NextResponse.json({ success: true, data: enrollment })
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Enrollment failed' }, { status: 500 })
  }
}
