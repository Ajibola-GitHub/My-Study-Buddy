// src/app/api/admin/stats/route.ts
// GET /api/admin/stats - Admin dashboard statistics

import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { subDays } from 'date-fns'

export async function GET(req: NextRequest) {
  try {
    const session = await auth()
    if (!session || !['ADMIN', 'SUPERADMIN'].includes(session.user.role)) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const oneWeekAgo = subDays(new Date(), 7)

    const [
      totalUsers,
      totalQuestions,
      totalSubjects,
      totalAttempts,
      newUsersThisWeek,
      attemptsThisWeek,
      recentUsers,
      topSubjects,
    ] = await Promise.all([
      db.user.count({ where: { role: 'STUDENT' } }),
      db.question.count({ where: { isActive: true } }),
      db.subject.count({ where: { isActive: true } }),
      db.practiceAttempt.count(),
      db.user.count({ where: { createdAt: { gte: oneWeekAgo }, role: 'STUDENT' } }),
      db.practiceAttempt.count({ where: { createdAt: { gte: oneWeekAgo } } }),

      // Recent registrations
      db.user.findMany({
        where: { role: 'STUDENT' },
        orderBy: { createdAt: 'desc' },
        take: 5,
        select: { id: true, fullName: true, email: true, classLevel: true, examType: true, createdAt: true },
      }),

      // Most practiced subjects
      db.practiceAttempt.groupBy({
        by: ['questionId'],
        _count: { _all: true },
      }).then(async () => {
        const attempts = await db.practiceAttempt.findMany({
          include: { question: { include: { subject: { select: { name: true, icon: true } } } } },
        })
        const counts: Record<string, { name: string; icon: string; count: number }> = {}
        for (const a of attempts) {
          const name = a.question.subject.name
          const icon = a.question.subject.icon || '📚'
          if (!counts[name]) counts[name] = { name, icon, count: 0 }
          counts[name].count++
        }
        return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 5)
      }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        totalUsers,
        totalQuestions,
        totalSubjects,
        totalAttempts,
        newUsersThisWeek,
        attemptsThisWeek,
        recentUsers,
        topSubjects,
      },
    })
  } catch (error) {
    console.error('[ADMIN_STATS_ERROR]', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch stats' }, { status: 500 })
  }
}
