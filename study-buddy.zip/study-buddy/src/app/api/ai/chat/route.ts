// src/app/api/ai/chat/route.ts
// POST /api/ai/chat - Send message to AI tutor (streaming)

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { openai, STUDY_BUDDY_SYSTEM_PROMPT, generateChatTitle } from '@/lib/openai'

const messageSchema = z.object({
  chatId: z.string().optional(),
  content: z.string().min(1).max(4000),
  imageUrl: z.string().url().optional(),
  subjectContext: z.string().optional(), // e.g. "Mathematics"
  examType: z.string().optional(),       // e.g. "WAEC"
})

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const data = messageSchema.parse(await req.json())
    const userId = session.user.id

    // Get or create chat session
    let chatId = data.chatId
    if (!chatId) {
      const chat = await db.aIChat.create({
        data: { userId, title: 'New Chat' },
      })
      chatId = chat.id
    }

    // Save user message to DB
    await db.aIMessage.create({
      data: {
        chatId,
        role: 'USER',
        content: data.content,
        imageUrl: data.imageUrl,
      },
    })

    // Get conversation history (last 20 messages)
    const history = await db.aIMessage.findMany({
      where: { chatId },
      orderBy: { createdAt: 'asc' },
      take: 20,
    })

    // Build OpenAI messages
    const systemPrompt = data.subjectContext
      ? `${STUDY_BUDDY_SYSTEM_PROMPT}\n\nThe student is studying ${data.subjectContext}${data.examType ? ` for ${data.examType}` : ''}. Focus your explanations accordingly.`
      : STUDY_BUDDY_SYSTEM_PROMPT

    const messages: any[] = history.map((msg) => {
      if (msg.imageUrl && msg.role === 'USER') {
        return {
          role: 'user',
          content: [
            { type: 'text', text: msg.content },
            { type: 'image_url', image_url: { url: msg.imageUrl } },
          ],
        }
      }
      return {
        role: msg.role === 'USER' ? 'user' : 'assistant',
        content: msg.content,
      }
    })

    // Call OpenAI
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [{ role: 'system', content: systemPrompt }, ...messages],
      max_tokens: 1500,
      temperature: 0.7,
    })

    const assistantContent = completion.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response. Please try again."

    // Save assistant response
    await db.aIMessage.create({
      data: {
        chatId,
        role: 'ASSISTANT',
        content: assistantContent,
      },
    })

    // Update chat title if this is the first exchange
    if (history.length <= 1) {
      const title = await generateChatTitle(data.content)
      await db.aIChat.update({
        where: { id: chatId },
        data: { title },
      })
    } else {
      await db.aIChat.update({
        where: { id: chatId },
        data: { updatedAt: new Date() },
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        chatId,
        content: assistantContent,
        tokensUsed: completion.usage?.total_tokens,
      },
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    console.error('[AI_CHAT_ERROR]', error)
    return NextResponse.json({ success: false, error: 'AI tutor is temporarily unavailable. Please try again.' }, { status: 500 })
  }
}

// GET /api/ai/chat - Get chat history list
export async function GET(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const chatId = searchParams.get('chatId')

    if (chatId) {
      // Get messages for a specific chat
      const messages = await db.aIMessage.findMany({
        where: { chatId },
        orderBy: { createdAt: 'asc' },
      })
      return NextResponse.json({ success: true, data: messages })
    }

    // Get all chats for user
    const chats = await db.aIChat.findMany({
      where: { userId: session.user.id },
      include: { _count: { select: { messages: true } } },
      orderBy: { updatedAt: 'desc' },
      take: 20,
    })

    return NextResponse.json({ success: true, data: chats })
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to fetch chats' }, { status: 500 })
  }
}
