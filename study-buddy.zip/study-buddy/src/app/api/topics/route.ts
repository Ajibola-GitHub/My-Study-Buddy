// src/app/api/topics/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const subjectId = searchParams.get('subjectId')
  const subjectSlug = searchParams.get('subjectSlug')

  try {
    let whereSubject: any = {}
    if (subjectId) whereSubject = { subjectId }
    if (subjectSlug) whereSubject = { subject: { slug: subjectSlug } }

    const topics = await db.topic.findMany({
      where: { isActive: true, ...whereSubject },
      include: { _count: { select: { questions: true } } },
      orderBy: { order: 'asc' },
    })

    return NextResponse.json({ success: true, data: topics })
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Failed to fetch topics' }, { status: 500 })
  }
}
