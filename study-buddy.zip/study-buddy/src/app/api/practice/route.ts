// src/app/api/practice/route.ts
// POST /api/practice - Submit a practice answer
// GET  /api/practice - Get practice history

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

const submitSchema = z.object({
  questionId: z.string().cuid(),
  selectedOptionId: z.string().cuid(),
  timeTaken: z.number().optional(),
  sessionId: z.string().optional(),
})

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const data = submitSchema.parse(await req.json())

    // Verify the question and selected option exist
    const question = await db.question.findUnique({
      where: { id: data.questionId },
      include: { options: true },
    })

    if (!question) {
      return NextResponse.json({ success: false, error: 'Question not found' }, { status: 404 })
    }

    const selectedOption = question.options.find((o) => o.id === data.selectedOptionId)
    if (!selectedOption) {
      return NextResponse.json({ success: false, error: 'Invalid option' }, { status: 400 })
    }

    const isCorrect = selectedOption.isCorrect
    const correctOption = question.options.find((o) => o.isCorrect)

    // Record the attempt
    const attempt = await db.practiceAttempt.create({
      data: {
        userId: session.user.id,
        questionId: data.questionId,
        selectedOptionId: data.selectedOptionId,
        isCorrect,
        timeTaken: data.timeTaken,
      },
    })

    // Update study session if provided
    if (data.sessionId) {
      await db.studySession.update({
        where: { id: data.sessionId },
        data: {
          questionsAttempted: { increment: 1 },
          correctAnswers: isCorrect ? { increment: 1 } : undefined,
        },
      })
    }

    // Update study streak
    await updateStudyStreak(session.user.id)

    return NextResponse.json({
      success: true,
      data: {
        isCorrect,
        correctOptionId: correctOption?.id,
        explanation: question.explanation,
        attempt,
      },
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ success: false, error: error.errors[0].message }, { status: 400 })
    }
    console.error('[PRACTICE_POST_ERROR]', error)
    return NextResponse.json({ success: false, error: 'Failed to submit answer' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const limit = Number(searchParams.get('limit')) || 20

    const attempts = await db.practiceAttempt.findMany({
      where: { userId: session.user.id },
      include: {
        question: {
          include: {
            subject: { select: { name: true, color: true, icon: true } },
            options: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ success: true, data: attempts })
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to fetch history' }, { status: 500 })
  }
}

/** Update the user's study streak */
async function updateStudyStreak(userId: string) {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { studyStreak: true, lastStudyDate: true },
  })

  if (!user) return

  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const lastStudy = user.lastStudyDate ? new Date(user.lastStudyDate) : null
  if (lastStudy) lastStudy.setHours(0, 0, 0, 0)

  const isToday = lastStudy?.getTime() === today.getTime()
  if (isToday) return // Already studied today

  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)
  const isYesterday = lastStudy?.getTime() === yesterday.getTime()

  await db.user.update({
    where: { id: userId },
    data: {
      lastStudyDate: new Date(),
      studyStreak: isYesterday ? { increment: 1 } : 1, // Extend streak or reset to 1
    },
  })
}
