// src/app/(admin)/admin/dashboard/page.tsx
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { Users, BookOpen, HelpCircle, BarChart3, TrendingUp, UserPlus } from 'lucide-react'
import Link from 'next/link'
import { subDays } from 'date-fns'

export const metadata = { title: 'Admin Dashboard' }

export default async function AdminDashboardPage() {
  const session = await auth()
  if (!session?.user || !['ADMIN', 'SUPERADMIN'].includes(session.user.role)) redirect('/dashboard')

  const oneWeekAgo = subDays(new Date(), 7)

  const [totalUsers, totalQuestions, totalSubjects, totalAttempts, newUsersThisWeek, recentUsers] = await Promise.all([
    db.user.count({ where: { role: 'STUDENT' } }),
    db.question.count(),
    db.subject.count(),
    db.practiceAttempt.count(),
    db.user.count({ where: { createdAt: { gte: oneWeekAgo }, role: 'STUDENT' } }),
    db.user.findMany({
      where: { role: 'STUDENT' },
      orderBy: { createdAt: 'desc' },
      take: 8,
      select: { id: true, fullName: true, email: true, classLevel: true, examType: true, createdAt: true },
    }),
  ])

  const stats = [
    { label: 'Total Students', value: totalUsers, icon: Users, color: 'text-brand-600', bg: 'bg-brand-50' },
    { label: 'Questions', value: totalQuestions, icon: HelpCircle, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Subjects', value: totalSubjects, icon: BookOpen, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Total Attempts', value: totalAttempts, icon: BarChart3, color: 'text-purple-600', bg: 'bg-purple-50' },
  ]

  return (
    <div className="min-h-screen bg-surface-50">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-500 text-sm mt-1">My Study Buddy · Platform Overview</p>
          </div>
          <div className="flex gap-3">
            <Link href="/admin/questions/new" className="px-4 py-2.5 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700 transition-colors">
              + Add Question
            </Link>
            <Link href="/dashboard" className="px-4 py-2.5 bg-white text-gray-600 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-colors border border-gray-200">
              Student View
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.bg} mb-3`}>
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <p className="text-2xl font-display font-bold text-gray-900">{s.value.toLocaleString()}</p>
              <p className="text-sm text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Quick info */}
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display font-semibold text-gray-900 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-brand-500" /> Recent Students
              </h2>
              <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">+{newUsersThisWeek} this week</span>
            </div>
            <div className="space-y-3">
              {recentUsers.map((u) => (
                <div key={u.id} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 text-sm font-bold shrink-0">
                    {u.fullName.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{u.fullName}</p>
                    <p className="text-xs text-gray-500 truncate">{u.email}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">{u.examType}</span>
                    <p className="text-xs text-gray-400 mt-0.5">{u.classLevel}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 className="font-display font-semibold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              {[
                { href: '/admin/questions', label: 'Manage Questions', desc: `${totalQuestions} total questions`, icon: '❓' },
                { href: '/admin/questions/new', label: 'Add New Question', desc: 'Create practice questions', icon: '➕' },
                { href: '/admin/users', label: 'Manage Users', desc: `${totalUsers} registered students`, icon: '👥' },
              ].map((item) => (
                <Link key={item.href} href={item.href}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-50 transition-colors border border-gray-50 hover:border-brand-100">
                  <span className="text-xl">{item.icon}</span>
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{item.label}</p>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
