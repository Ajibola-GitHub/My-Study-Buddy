// src/app/(admin)/admin/questions/page.tsx
import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import Link from 'next/link'
import { getDifficultyColor, getExamTypeColor } from '@/lib/utils'

export const metadata = { title: 'Question Management' }

export default async function AdminQuestionsPage() {
  const session = await auth()
  if (!session?.user || !['ADMIN', 'SUPERADMIN'].includes(session.user.role)) redirect('/dashboard')

  const questions = await db.question.findMany({
    include: {
      subject: { select: { name: true, icon: true } },
      topic: { select: { name: true } },
      options: { where: { isCorrect: true }, select: { label: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="min-h-screen bg-surface-50">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-gray-900">Question Bank</h1>
            <p className="text-gray-500 text-sm mt-1">{questions.length} questions loaded</p>
          </div>
          <div className="flex gap-3">
            <Link href="/admin/questions/new" className="px-4 py-2.5 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700">
              + Add Question
            </Link>
            <Link href="/admin/dashboard" className="px-4 py-2.5 bg-white text-gray-600 rounded-xl text-sm font-semibold border border-gray-200 hover:bg-gray-50">
              ← Dashboard
            </Link>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-surface-50 border-b border-gray-100">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Question</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden md:table-cell">Subject</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden lg:table-cell">Exam</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden lg:table-cell">Difficulty</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Answer</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {questions.map((q) => (
                <tr key={q.id} className="hover:bg-surface-50 transition-colors">
                  <td className="px-4 py-3.5">
                    <p className="text-gray-800 font-medium line-clamp-2 max-w-xs">{q.text}</p>
                  </td>
                  <td className="px-4 py-3.5 hidden md:table-cell">
                    <span className="text-gray-600">{q.subject.icon} {q.subject.name}</span>
                    {q.topic && <p className="text-xs text-gray-400">{q.topic.name}</p>}
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getExamTypeColor(q.examType)}`}>{q.examType}</span>
                  </td>
                  <td className="px-4 py-3.5 hidden lg:table-cell">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getDifficultyColor(q.difficulty)}`}>{q.difficulty}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="font-bold text-brand-700">{q.options[0]?.label || '?'}</span>
                  </td>
                  <td className="px-4 py-3.5 text-right">
                    <Link href={`/admin/questions/${q.id}/edit`} className="text-xs text-brand-600 hover:text-brand-700 font-medium">Edit</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
