// src/app/(student)/subjects/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { SubjectCard } from '@/components/subjects/SubjectCard'
import { Search } from 'lucide-react'
import type { Subject } from '@/types'

export default function SubjectsPage() {
  const [all, setAll] = useState<Subject[]>([])
  const [enrolled, setEnrolled] = useState<Subject[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [enrollingId, setEnrollingId] = useState<string | null>(null)

  useEffect(() => {
    Promise.all([
      fetch('/api/subjects').then((r) => r.json()),
      fetch('/api/subjects?enrolled=true').then((r) => r.json()),
    ]).then(([allData, enrolledData]) => {
      setAll(allData.data || [])
      setEnrolled(enrolledData.data || [])
      setLoading(false)
    })
  }, [])

  const enrolledIds = new Set(enrolled.map((s) => s.id))

  const handleEnroll = async (subjectId: string) => {
    setEnrollingId(subjectId)
    await fetch('/api/subjects/enroll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subjectId }),
    })
    setEnrolled((prev) => [...prev, all.find((s) => s.id === subjectId)!])
    setEnrollingId(null)
  }

  const filtered = all.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900">Subject Library</h1>
        <p className="text-gray-500 mt-1 text-sm">Enroll in subjects and start practicing questions</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          placeholder="Search subjects..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
      </div>

      {enrolled.length > 0 && (
        <div>
          <h2 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">My Enrolled Subjects</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {enrolled.map((s) => (
              <SubjectCard key={s.id} subject={s} isEnrolled />
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="font-semibold text-gray-700 mb-3 text-sm uppercase tracking-wide">All Subjects</h2>
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-48 rounded-2xl skeleton" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((s) => (
              <SubjectCard
                key={s.id}
                subject={s}
                isEnrolled={enrolledIds.has(s.id)}
                onEnroll={handleEnroll}
                enrolling={enrollingId === s.id}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
