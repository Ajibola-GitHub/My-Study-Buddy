// src/app/(student)/practice/page.tsx
'use client'

import { useEffect, useState, useCallback } from 'react'
import { QuestionCard } from '@/components/practice/QuestionCard'
import { Button } from '@/components/ui/button'
import { getScoreGrade, shuffle } from '@/lib/utils'
import { PlayCircle, RotateCcw, Trophy, BookOpen } from 'lucide-react'
import Link from 'next/link'
import type { Question } from '@/types'

type Stage = 'setup' | 'playing' | 'results'

export default function PracticePage() {
  const [subjects, setSubjects] = useState<any[]>([])
  const [questions, setQuestions] = useState<Question[]>([])
  const [current, setCurrent] = useState(0)
  const [score, setScore] = useState(0)
  const [stage, setStage] = useState<Stage>('setup')
  const [loading, setLoading] = useState(false)
  const [config, setConfig] = useState({ subjectId: '', difficulty: '', limit: '10' })

  useEffect(() => {
    fetch('/api/subjects?enrolled=true').then((r) => r.json()).then((d) => setSubjects(d.data || []))
  }, [])

  const startSession = async () => {
    setLoading(true)
    const params = new URLSearchParams({ limit: config.limit })
    if (config.subjectId) params.set('subjectId', config.subjectId)
    if (config.difficulty) params.set('difficulty', config.difficulty)

    const res = await fetch(`/api/questions?${params}`)
    const data = await res.json()
    const qs = shuffle(data.data || [])
    setQuestions(qs)
    setCurrent(0)
    setScore(0)
    setStage('playing')
    setLoading(false)
  }

  const handleAnswer = useCallback(async (questionId: string, optionId: string) => {
    const res = await fetch('/api/practice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ questionId, selectedOptionId: optionId }),
    })
    const data = await res.json()
    if (data.data.isCorrect) setScore((s) => s + 1)
    return data.data
  }, [])

  const handleNext = () => {
    if (current + 1 >= questions.length) {
      setStage('results')
    } else {
      setCurrent((c) => c + 1)
    }
  }

  const pct = Math.round((score / questions.length) * 100)
  const { grade, emoji, color } = questions.length > 0 ? getScoreGrade(pct) : { grade: '', emoji: '', color: '' }

  if (stage === 'setup') {
    return (
      <div className="max-w-lg mx-auto space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Practice Questions</h1>
          <p className="text-gray-500 mt-1 text-sm">Configure your practice session and test your knowledge</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Subject (optional)</label>
            <select value={config.subjectId} onChange={(e) => setConfig({ ...config, subjectId: e.target.value })}
              className="w-full h-11 px-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
              <option value="">All Subjects (Mixed)</option>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.icon} {s.name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Difficulty</label>
            <div className="grid grid-cols-4 gap-2">
              {['', 'EASY', 'MEDIUM', 'HARD'].map((d) => (
                <button key={d} onClick={() => setConfig({ ...config, difficulty: d })}
                  className={`py-2 rounded-xl text-sm font-semibold border transition-all ${config.difficulty === d ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-200'}`}>
                  {d || 'Any'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Number of Questions</label>
            <div className="grid grid-cols-4 gap-2">
              {['5', '10', '20', '30'].map((n) => (
                <button key={n} onClick={() => setConfig({ ...config, limit: n })}
                  className={`py-2 rounded-xl text-sm font-semibold border transition-all ${config.limit === n ? 'bg-brand-600 text-white border-brand-600' : 'bg-white text-gray-600 border-gray-200 hover:border-brand-200'}`}>
                  {n}
                </button>
              ))}
            </div>
          </div>

          <Button onClick={startSession} className="w-full" size="lg" loading={loading}>
            <PlayCircle className="w-4 h-4" /> Start Practice Session
          </Button>
        </div>

        <div className="bg-brand-50 rounded-2xl p-5 border border-brand-100">
          <p className="text-sm font-semibold text-brand-800 mb-2">💡 Pro Tips</p>
          <ul className="text-sm text-brand-700 space-y-1">
            <li>• Read each question carefully before answering</li>
            <li>• Review explanations even when you get it right</li>
            <li>• Practice daily to maintain your streak 🔥</li>
          </ul>
        </div>
      </div>
    )
  }

  if (stage === 'results') {
    return (
      <div className="max-w-lg mx-auto animate-fade-in">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 text-center">
          <div className="text-6xl mb-4">{emoji}</div>
          <h2 className="font-display text-2xl font-bold text-gray-900">{grade}!</h2>
          <p className="text-gray-500 mt-1">You've completed the session</p>

          <div className="mt-6 mb-6">
            <div className="text-5xl font-display font-bold mb-1" style={{ color: pct >= 70 ? '#10B981' : pct >= 50 ? '#F59E0B' : '#EF4444' }}>
              {pct}%
            </div>
            <p className="text-gray-500 text-sm">{score} out of {questions.length} correct</p>
          </div>

          <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden mb-6">
            <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${pct}%`, backgroundColor: pct >= 70 ? '#10B981' : pct >= 50 ? '#F59E0B' : '#EF4444' }} />
          </div>

          <div className="flex gap-3">
            <Button onClick={() => { setStage('setup'); setQuestions([]) }} variant="outline" className="flex-1">
              <RotateCcw className="w-4 h-4" /> Try Again
            </Button>
            <Button onClick={startSession} className="flex-1" loading={loading}>
              <PlayCircle className="w-4 h-4" /> New Session
            </Button>
          </div>

          <Link href="/ai-tutor" className="mt-4 block text-sm text-brand-600 font-medium hover:text-brand-700">
            Need help? Ask the AI Tutor →
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      {questions.length > 0 && (
        <QuestionCard
          question={questions[current]}
          questionNumber={current + 1}
          total={questions.length}
          onAnswer={handleAnswer}
          onNext={handleNext}
          isLast={current + 1 === questions.length}
        />
      )}
    </div>
  )
}
