// src/app/(student)/dashboard/page.tsx
// Main student dashboard with stats, progress, and quick actions

import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { StatsCard } from '@/components/dashboard/StatsCard'
import {
  Target, Zap, BookOpen, MessageSquare, Flame, TrendingUp,
  ChevronRight, PlayCircle, Brain, Trophy
} from 'lucide-react'
import { toPercent, timeAgo } from '@/lib/utils'
import { subDays, format, startOfDay } from 'date-fns'

export const metadata = { title: 'Dashboard' }

async function getDashboardData(userId: string) {
  const [user, attempts, aiChats, enrollments, recentAttempts, subjects] = await Promise.all([
    db.user.findUnique({
      where: { id: userId },
      select: { fullName: true, studyStreak: true, examType: true, classLevel: true },
    }),
    db.practiceAttempt.aggregate({
      where: { userId },
      _count: { _all: true },
    }),
    db.aIChat.count({ where: { userId } }),
    db.enrollment.count({ where: { userId } }),
    db.practiceAttempt.findMany({
      where: { userId },
      include: { question: { include: { subject: { select: { name: true, icon: true, color: true } } } } },
      orderBy: { createdAt: 'desc' },
      take: 8,
    }),
    db.enrollment.findMany({
      where: { userId },
      include: {
        subject: {
          include: { _count: { select: { questions: true, topics: true } } },
        },
      },
      take: 4,
    }),
  ])

  // Correct answers count
  const correct = await db.practiceAttempt.count({ where: { userId, isCorrect: true } })

  // Weekly data
  const weeklyData = await Promise.all(
    Array.from({ length: 7 }, (_, i) => {
      const date = startOfDay(subDays(new Date(), 6 - i))
      const nextDate = startOfDay(subDays(new Date(), 5 - i))
      return db.practiceAttempt
        .findMany({ where: { userId, createdAt: { gte: date, lt: nextDate } } })
        .then((a) => ({
          day: format(date, 'EEE'),
          attempts: a.length,
          correct: a.filter((x) => x.isCorrect).length,
        }))
    })
  )

  return { user, attempts: attempts._count._all, correct, aiChats, enrollments, recentAttempts, subjects, weeklyData }
}

export default async function DashboardPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/login')

  const { user, attempts, correct, aiChats, enrollments, recentAttempts, subjects, weeklyData } = await getDashboardData(session.user.id)

  const accuracy = toPercent(correct, attempts)
  const firstName = user?.fullName.split(' ')[0] || 'Student'
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  const maxAttempts = Math.max(...weeklyData.map((d) => d.attempts), 1)

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">
            {greeting}, {firstName}! 👋
          </h1>
          <p className="text-gray-500 mt-1 text-sm">
            {user?.classLevel} · {user?.examType} Candidate · Ready to study?
          </p>
        </div>
        <div className="flex gap-3">
          <Link
            href="/practice"
            className="flex items-center gap-2 px-4 py-2.5 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700 transition-colors shadow-sm"
          >
            <PlayCircle className="w-4 h-4" />
            Practice Now
          </Link>
          <Link
            href="/ai-tutor"
            className="flex items-center gap-2 px-4 py-2.5 bg-white text-gray-700 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-colors border border-gray-100 shadow-sm"
          >
            <Brain className="w-4 h-4" />
            Ask AI
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Questions Attempted"
          value={attempts}
          icon={Target}
          iconColor="text-brand-600"
          iconBg="bg-brand-50"
          subtitle="Total practice"
        />
        <StatsCard
          title="Accuracy Rate"
          value={`${accuracy}%`}
          icon={TrendingUp}
          iconColor="text-emerald-600"
          iconBg="bg-emerald-50"
          subtitle={`${correct} correct`}
        />
        <StatsCard
          title="Study Streak"
          value={`${user?.studyStreak || 0} days`}
          icon={Flame}
          iconColor="text-orange-500"
          iconBg="bg-orange-50"
          subtitle="Keep it up! 🔥"
        />
        <StatsCard
          title="AI Chats"
          value={aiChats}
          icon={MessageSquare}
          iconColor="text-purple-600"
          iconBg="bg-purple-50"
          subtitle={`${enrollments} subjects`}
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Weekly Activity */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-display font-semibold text-gray-900">Weekly Activity</h2>
            <span className="text-xs text-gray-400">Last 7 days</span>
          </div>
          <div className="flex items-end gap-2 h-32">
            {weeklyData.map((day, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col items-center justify-end" style={{ height: '100px' }}>
                  {day.attempts > 0 && (
                    <div
                      className="w-full rounded-t-lg bg-brand-500 transition-all duration-700 relative group cursor-default"
                      style={{ height: `${(day.attempts / maxAttempts) * 100}%`, minHeight: '4px' }}
                    >
                      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                        {day.attempts} attempts
                      </div>
                    </div>
                  )}
                  {day.attempts === 0 && <div className="w-full h-1 bg-gray-100 rounded" />}
                </div>
                <span className="text-xs text-gray-400">{day.day}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-50 flex items-center gap-4 text-xs text-gray-500">
            <span>Total: <strong className="text-gray-900">{weeklyData.reduce((s, d) => s + d.attempts, 0)}</strong> attempts</span>
            <span>Correct: <strong className="text-emerald-600">{weeklyData.reduce((s, d) => s + d.correct, 0)}</strong></span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-4">
          <div className="bg-gradient-to-br from-brand-600 to-blue-500 rounded-2xl p-5 text-white">
            <Trophy className="w-7 h-7 mb-3 text-yellow-300" />
            <h3 className="font-display font-bold text-lg">Score 80%+?</h3>
            <p className="text-blue-100 text-sm mt-1">
              Challenge yourself with harder questions and boost your exam readiness!
            </p>
            <Link
              href="/practice?difficulty=HARD"
              className="mt-3 inline-flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white text-sm font-semibold px-3 py-2 rounded-xl transition-colors"
            >
              Try Hard Mode <Zap className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h3 className="font-display font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-brand-500" />
              My Subjects
            </h3>
            <div className="space-y-2">
              {subjects.slice(0, 3).map(({ subject }) => (
                <Link
                  key={subject.id}
                  href={`/subjects/${subject.slug}`}
                  className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-surface-50 transition-colors group"
                >
                  <span className="text-xl">{subject.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{subject.name}</p>
                    <p className="text-xs text-gray-400">{subject._count.questions} questions</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-500 transition-colors" />
                </Link>
              ))}
              <Link
                href="/subjects"
                className="block text-center text-xs text-brand-600 font-medium hover:text-brand-700 py-2"
              >
                View all subjects →
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      {recentAttempts.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <h2 className="font-display font-semibold text-gray-900 mb-4">Recent Practice</h2>
          <div className="space-y-2">
            {recentAttempts.map((attempt) => (
              <div
                key={attempt.id}
                className="flex items-center gap-3 py-2.5 border-b border-gray-50 last:border-0"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${attempt.isCorrect ? 'bg-emerald-50' : 'bg-red-50'}`}>
                  {attempt.isCorrect ? '✅' : '❌'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-700 truncate">{attempt.question.subject.icon} {attempt.question.subject.name}</p>
                  <p className="text-xs text-gray-400">{timeAgo(attempt.createdAt)}</p>
                </div>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${attempt.isCorrect ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                  {attempt.isCorrect ? 'Correct' : 'Wrong'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state for new users */}
      {attempts === 0 && (
        <div className="bg-gradient-to-br from-brand-50 to-blue-50 rounded-2xl border border-brand-100 p-8 text-center">
          <div className="text-5xl mb-4">🚀</div>
          <h3 className="font-display font-bold text-xl text-gray-900 mb-2">Start Your Journey!</h3>
          <p className="text-gray-600 mb-6 max-w-md mx-auto">
            You haven't practiced any questions yet. Start now and build your exam confidence!
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/practice" className="flex items-center justify-center gap-2 px-6 py-3 bg-brand-600 text-white rounded-xl font-semibold hover:bg-brand-700 transition-colors">
              <PlayCircle className="w-4 h-4" /> Start Practicing
            </Link>
            <Link href="/ai-tutor" className="flex items-center justify-center gap-2 px-6 py-3 bg-white text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors border border-gray-200">
              <Brain className="w-4 h-4" /> Ask the AI Tutor
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
