// src/app/(student)/profile/page.tsx
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { redirect } from 'next/navigation'
import { ProfileForm } from './ProfileForm'

export const metadata = { title: 'My Profile' }

export default async function ProfilePage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/login')

  const user = await db.user.findUnique({
    where: { id: session.user.id },
    select: {
      id: true, fullName: true, email: true, classLevel: true, examType: true,
      studyStreak: true, createdAt: true,
      _count: { select: { practiceAttempts: true, aiChats: true, enrollments: true } },
    },
  })

  if (!user) redirect('/login')

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900">My Profile</h1>
        <p className="text-gray-500 mt-1 text-sm">Manage your account and preferences</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Questions', value: user._count.practiceAttempts },
          { label: 'AI Chats', value: user._count.aiChats },
          { label: 'Subjects', value: user._count.enrollments },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-4 text-center shadow-sm">
            <p className="text-2xl font-display font-bold text-gray-900">{s.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <ProfileForm user={user} />
    </div>
  )
}
