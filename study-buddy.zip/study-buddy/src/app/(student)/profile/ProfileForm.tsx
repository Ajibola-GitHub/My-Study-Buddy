// src/app/(student)/profile/ProfileForm.tsx
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { CheckCircle2 } from 'lucide-react'

interface Props {
  user: { id: string; fullName: string; email: string; classLevel: string; examType: string }
}

export function ProfileForm({ user }: Props) {
  const [form, setForm] = useState({ fullName: user.fullName, classLevel: user.classLevel, examType: user.examType })
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const res = await fetch('/api/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    setLoading(false)
    if (res.ok) { setSaved(true); setTimeout(() => setSaved(false), 3000) }
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
      <h2 className="font-display font-semibold text-gray-900 mb-5">Account Details</h2>
      <form onSubmit={handleSave} className="space-y-4">
        <Input label="Full Name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
        <Input label="Email Address" value={user.email} disabled className="opacity-60" />

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Class Level</label>
            <select value={form.classLevel} onChange={(e) => setForm({ ...form, classLevel: e.target.value })}
              className="w-full h-11 px-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
              {['SS1', 'SS2', 'SS3'].map((l) => <option key={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Target Exam</label>
            <select value={form.examType} onChange={(e) => setForm({ ...form, examType: e.target.value })}
              className="w-full h-11 px-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500">
              {['WAEC', 'NECO', 'JAMB'].map((e) => <option key={e}>{e}</option>)}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button type="submit" loading={loading}>Save Changes</Button>
          {saved && <span className="flex items-center gap-1.5 text-sm text-emerald-600 font-medium"><CheckCircle2 className="w-4 h-4" /> Saved!</span>}
        </div>
      </form>
    </div>
  )
}
