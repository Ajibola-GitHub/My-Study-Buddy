// src/app/(student)/layout.tsx
// Layout for all authenticated student pages

import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { db } from '@/lib/db'
import { Sidebar, MobileNav } from '@/components/layout/Sidebar'

export default async function StudentLayout({ children }: { children: React.ReactNode }) {
  const session = await auth()

  if (!session?.user) {
    redirect('/login')
  }

  // Fetch user with streak info
  const user = await db.user.findUnique({
    where: { id: session.user.id },
    select: {
      fullName: true,
      email: true,
      image: true,
      examType: true,
      studyStreak: true,
    },
  })

  if (!user) redirect('/login')

  return (
    <div className="min-h-screen bg-surface-50">
      <Sidebar user={user} />

      {/* Main content */}
      <main className="lg:pl-64 pb-20 lg:pb-0">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
          {children}
        </div>
      </main>

      {/* Mobile bottom nav */}
      <MobileNav />
    </div>
  )
}
