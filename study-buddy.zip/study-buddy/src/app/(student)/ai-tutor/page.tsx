// src/app/(student)/ai-tutor/page.tsx
import { ChatInterface } from '@/components/ai/ChatInterface'

export const metadata = { title: 'AI Tutor' }

export default function AITutorPage() {
  return (
    <div className="animate-fade-in flex flex-col h-[calc(100vh-8rem)]">
      <div className="mb-4">
        <h1 className="font-display text-2xl font-bold text-gray-900">AI Study Tutor</h1>
        <p className="text-gray-500 mt-1 text-sm">
          Ask any question about your subjects. Get step-by-step WAEC/NECO/JAMB style explanations.
        </p>
      </div>
      <div className="flex-1 min-h-0">
        <ChatInterface />
      </div>
    </div>
  )
}
