// src/types/next-auth.d.ts
import type { DefaultSession } from 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      role: string
      fullName: string
      examType: string
      classLevel: string
    } & DefaultSession['user']
  }
}
