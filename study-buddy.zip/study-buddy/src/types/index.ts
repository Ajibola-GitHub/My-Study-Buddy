// src/types/index.ts
// Centralized TypeScript types for My Study Buddy

export type Role = 'STUDENT' | 'ADMIN' | 'SUPERADMIN'
export type ExamType = 'WAEC' | 'NECO' | 'JAMB' | 'ALL'
export type ClassLevel = 'SS1' | 'SS2' | 'SS3'
export type Difficulty = 'EASY' | 'MEDIUM' | 'HARD'
export type MessageRole = 'USER' | 'ASSISTANT'

// ── User ─────────────────────────────────────────────────────
export interface User {
  id: string
  fullName: string
  email: string
  image?: string | null
  role: Role
  classLevel: ClassLevel
  examType: ExamType
  studyStreak: number
  lastStudyDate?: Date | null
  createdAt: Date
}

export interface UserProfile extends User {
  enrollments: Array<{ subject: Subject }>
  _count: {
    practiceAttempts: number
    aiChats: number
  }
}

// ── Subject & Curriculum ─────────────────────────────────────
export interface Subject {
  id: string
  name: string
  slug: string
  description?: string | null
  icon?: string | null
  color?: string | null
  examTypes: ExamType[]
  isActive: boolean
  _count?: {
    topics: number
    questions: number
  }
}

export interface Topic {
  id: string
  subjectId: string
  name: string
  slug: string
  description?: string | null
  order: number
  isActive: boolean
  subject?: Subject
  _count?: {
    questions: number
  }
}

// ── Questions ────────────────────────────────────────────────
export interface QuestionOption {
  id: string
  questionId: string
  label: string
  text: string
  isCorrect: boolean
}

export interface Question {
  id: string
  subjectId: string
  topicId?: string | null
  text: string
  imageUrl?: string | null
  examType: ExamType
  examYear?: number | null
  difficulty: Difficulty
  explanation: string
  isActive: boolean
  subject?: Subject
  topic?: Topic | null
  options: QuestionOption[]
}

// ── Practice ─────────────────────────────────────────────────
export interface PracticeAttempt {
  id: string
  userId: string
  questionId: string
  selectedOptionId?: string | null
  isCorrect: boolean
  timeTaken?: number | null
  createdAt: Date
  question?: Question
}

export interface StudySession {
  id: string
  userId: string
  subjectId?: string | null
  startedAt: Date
  endedAt?: Date | null
  duration?: number | null
  questionsAttempted: number
  correctAnswers: number
  subject?: Subject | null
}

// ── AI Chat ──────────────────────────────────────────────────
export interface AIMessage {
  id: string
  chatId: string
  role: MessageRole
  content: string
  imageUrl?: string | null
  createdAt: Date
}

export interface AIChat {
  id: string
  userId: string
  title?: string | null
  createdAt: Date
  updatedAt: Date
  messages?: AIMessage[]
}

// ── Analytics ────────────────────────────────────────────────
export interface SubjectPerformance {
  subjectId: string
  subjectName: string
  subjectColor: string
  totalAttempts: number
  correctAnswers: number
  percentage: number
}

export interface DashboardStats {
  totalAttempts: number
  correctAnswers: number
  wrongAnswers: number
  accuracy: number
  studyStreak: number
  aiChatsUsed: number
  subjectsEnrolled: number
  recentActivity: RecentActivity[]
  subjectPerformance: SubjectPerformance[]
  weeklyProgress: WeeklyProgress[]
}

export interface RecentActivity {
  id: string
  type: 'practice' | 'ai_chat' | 'enrollment'
  description: string
  timestamp: Date
}

export interface WeeklyProgress {
  day: string
  attempts: number
  correct: number
}

// ── Admin ────────────────────────────────────────────────────
export interface AdminStats {
  totalUsers: number
  totalQuestions: number
  totalSubjects: number
  totalAttempts: number
  newUsersThisWeek: number
  attemptsThisWeek: number
}

// ── API Responses ────────────────────────────────────────────
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}

// ── Form Types ────────────────────────────────────────────────
export interface LoginForm {
  email: string
  password: string
}

export interface SignupForm {
  fullName: string
  email: string
  password: string
  confirmPassword: string
  classLevel: ClassLevel
  examType: ExamType
}

export interface QuestionForm {
  subjectId: string
  topicId?: string
  text: string
  imageUrl?: string
  examType: ExamType
  examYear?: number
  difficulty: Difficulty
  explanation: string
  options: {
    label: string
    text: string
    isCorrect: boolean
  }[]
}

// ── Practice Session ─────────────────────────────────────────
export interface PracticeQuestion extends Question {
  selectedOption?: string
  isAnswered: boolean
  isCorrect?: boolean
}

export interface PracticeSessionState {
  sessionId: string
  questions: PracticeQuestion[]
  currentIndex: number
  score: number
  startTime: number
  isComplete: boolean
}
