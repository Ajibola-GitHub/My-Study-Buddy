// prisma/seed.ts
// Seeds the database with subjects, topics, and sample questions

import { PrismaClient, ExamType, Difficulty } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

const subjects = [
  { name: 'Mathematics', slug: 'mathematics', icon: '📐', color: '#3B82F6', description: 'Numbers, algebra, geometry, calculus and more', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'English Language', slug: 'english', icon: '📚', color: '#8B5CF6', description: 'Reading comprehension, grammar, and writing', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Physics', slug: 'physics', icon: '⚡', color: '#F59E0B', description: 'Mechanics, electricity, waves and modern physics', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Chemistry', slug: 'chemistry', icon: '🧪', color: '#10B981', description: 'Organic, inorganic chemistry and chemical reactions', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Biology', slug: 'biology', icon: '🌿', color: '#22C55E', description: 'Living organisms, genetics, ecology and evolution', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Economics', slug: 'economics', icon: '📊', color: '#EF4444', description: 'Micro and macroeconomics, trade, and development', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Government', slug: 'government', icon: '🏛️', color: '#6366F1', description: 'Nigerian governance, constitution and political science', examTypes: ['WAEC', 'NECO', 'JAMB'] },
  { name: 'Commerce', slug: 'commerce', icon: '🏪', color: '#F97316', description: 'Trade, business, banking and commerce principles', examTypes: ['WAEC', 'NECO'] },
  { name: 'CRS', slug: 'crs', icon: '✝️', color: '#EC4899', description: 'Christian Religious Studies - Bible and Christian living', examTypes: ['WAEC', 'NECO'] },
  { name: 'Literature', slug: 'literature', icon: '📖', color: '#14B8A6', description: 'Prose, poetry, drama and literary appreciation', examTypes: ['WAEC', 'NECO'] },
]

const topicsPerSubject: Record<string, string[]> = {
  mathematics: ['Number and Numeration', 'Algebra', 'Geometry', 'Trigonometry', 'Statistics and Probability', 'Calculus', 'Vectors and Matrices', 'Logarithms'],
  english: ['Comprehension', 'Summary Writing', 'Lexis and Structure', 'Essay Writing', 'Oral English', 'Literature in English'],
  physics: ['Mechanics', 'Thermal Physics', 'Waves and Sound', 'Light and Optics', 'Electricity and Magnetism', 'Modern Physics', 'Atomic Structure'],
  chemistry: ['Atomic Structure', 'Chemical Bonding', 'States of Matter', 'Chemical Kinetics', 'Equilibrium', 'Organic Chemistry', 'Electrochemistry', 'Industrial Chemistry'],
  biology: ['Cell Biology', 'Genetics and Evolution', 'Ecology', 'Plant Biology', 'Animal Biology', 'Reproduction', 'Nutrition', 'Diseases and Health'],
  economics: ['Basic Economic Concepts', 'Demand and Supply', 'Market Structures', 'National Income', 'Money and Banking', 'International Trade', 'Economic Development'],
  government: ['Nature of Government', 'Nigerian Constitution', 'Federalism', 'Legislature', 'Executive', 'Judiciary', 'Political Parties', 'Public Administration'],
  commerce: ['Business Organisation', 'Trade', 'Banking and Finance', 'Insurance', 'Transportation', 'Communication', 'Warehousing'],
  crs: ['Creation and Fall', 'The Patriarchs', 'The Exodus', 'The Prophets', 'New Testament', 'Life of Jesus', 'Early Church'],
  literature: ['Prose Fiction', 'Poetry', 'Drama', 'Literary Devices', 'Oral Literature', 'African Literature'],
}

// Sample questions for Mathematics
const mathQuestions = [
  {
    text: 'If 2x + 3 = 11, what is the value of x?',
    options: [{ label: 'A', text: '3', isCorrect: false }, { label: 'B', text: '4', isCorrect: true }, { label: 'C', text: '5', isCorrect: false }, { label: 'D', text: '6', isCorrect: false }],
    explanation: 'To solve 2x + 3 = 11:\nStep 1: Subtract 3 from both sides: 2x = 11 - 3 = 8\nStep 2: Divide both sides by 2: x = 8 ÷ 2 = 4\nTherefore x = 4.',
    difficulty: 'EASY',
    examType: 'WAEC',
    topicSlug: 'algebra',
  },
  {
    text: 'The sum of angles in a triangle is:',
    options: [{ label: 'A', text: '90°', isCorrect: false }, { label: 'B', text: '180°', isCorrect: true }, { label: 'C', text: '270°', isCorrect: false }, { label: 'D', text: '360°', isCorrect: false }],
    explanation: 'The interior angles of any triangle always add up to 180°. This is a fundamental theorem in Euclidean geometry. For example, a right-angled triangle has angles 90°, 45°, 45° which sum to 180°.',
    difficulty: 'EASY',
    examType: 'WAEC',
    topicSlug: 'geometry',
  },
  {
    text: 'Evaluate log₁₀(1000)',
    options: [{ label: 'A', text: '2', isCorrect: false }, { label: 'B', text: '3', isCorrect: true }, { label: 'C', text: '4', isCorrect: false }, { label: 'D', text: '10', isCorrect: false }],
    explanation: 'log₁₀(1000) asks: "To what power must we raise 10 to get 1000?"\n10¹ = 10\n10² = 100\n10³ = 1000\nTherefore log₁₀(1000) = 3.',
    difficulty: 'MEDIUM',
    examType: 'JAMB',
    topicSlug: 'logarithms',
  },
  {
    text: 'If the probability of rain on any given day is 0.3, what is the probability that it will NOT rain?',
    options: [{ label: 'A', text: '0.3', isCorrect: false }, { label: 'B', text: '0.5', isCorrect: false }, { label: 'C', text: '0.7', isCorrect: true }, { label: 'D', text: '1.3', isCorrect: false }],
    explanation: 'The probability of an event NOT happening = 1 - P(event)\nP(no rain) = 1 - P(rain) = 1 - 0.3 = 0.7\nThe probabilities of an event and its complement always add up to 1.',
    difficulty: 'EASY',
    examType: 'WAEC',
    topicSlug: 'statistics-and-probability',
  },
]

// Sample questions for Biology
const bioQuestions = [
  {
    text: 'Which organelle is responsible for producing energy (ATP) in a cell?',
    options: [{ label: 'A', text: 'Nucleus', isCorrect: false }, { label: 'B', text: 'Ribosome', isCorrect: false }, { label: 'C', text: 'Mitochondria', isCorrect: true }, { label: 'D', text: 'Golgi Apparatus', isCorrect: false }],
    explanation: 'The mitochondria is often called the "powerhouse of the cell" because it produces ATP (Adenosine Triphosphate) through a process called cellular respiration. ATP is the energy currency that powers all cellular activities.',
    difficulty: 'EASY',
    examType: 'WAEC',
    topicSlug: 'cell-biology',
  },
  {
    text: 'The process by which plants make their own food using sunlight is called:',
    options: [{ label: 'A', text: 'Respiration', isCorrect: false }, { label: 'B', text: 'Transpiration', isCorrect: false }, { label: 'C', text: 'Photosynthesis', isCorrect: true }, { label: 'D', text: 'Digestion', isCorrect: false }],
    explanation: 'Photosynthesis is the process where plants use sunlight, water (H₂O), and carbon dioxide (CO₂) to produce glucose (food) and oxygen. The equation is:\n6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂\nThis takes place mainly in the leaves in chloroplasts.',
    difficulty: 'EASY',
    examType: 'JAMB',
    topicSlug: 'plant-biology',
  },
]

// Sample questions for Chemistry
const chemQuestions = [
  {
    text: 'The atomic number of an element represents the number of:',
    options: [{ label: 'A', text: 'Neutrons in the nucleus', isCorrect: false }, { label: 'B', text: 'Protons in the nucleus', isCorrect: true }, { label: 'C', text: 'Electrons in the outer shell', isCorrect: false }, { label: 'D', text: 'Nucleons in the atom', isCorrect: false }],
    explanation: 'The atomic number (Z) of an element is the number of protons in the nucleus of an atom of that element. It uniquely identifies the element. For example, Carbon has atomic number 6, meaning it has 6 protons. In a neutral atom, the number of electrons equals the number of protons.',
    difficulty: 'EASY',
    examType: 'WAEC',
    topicSlug: 'atomic-structure',
  },
]

async function main() {
  console.log('🌱 Starting database seed...')

  // Create admin user
  const adminHash = await bcrypt.hash('Admin@123', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@studybuddy.ng' },
    update: {},
    create: {
      fullName: 'Study Buddy Admin',
      email: 'admin@studybuddy.ng',
      passwordHash: adminHash,
      role: 'ADMIN',
      classLevel: 'SS3',
      examType: 'WAEC',
    },
  })
  console.log(`✅ Admin user created: ${admin.email}`)

  // Create demo student
  const studentHash = await bcrypt.hash('Student@123', 12)
  const student = await prisma.user.upsert({
    where: { email: 'student@studybuddy.ng' },
    update: {},
    create: {
      fullName: 'Chidi Okonkwo',
      email: 'student@studybuddy.ng',
      passwordHash: studentHash,
      role: 'STUDENT',
      classLevel: 'SS3',
      examType: 'WAEC',
    },
  })
  console.log(`✅ Demo student created: ${student.email}`)

  // Create subjects
  const createdSubjects: Record<string, any> = {}
  for (const subject of subjects) {
    const { examTypes, ...rest } = subject
    const created = await prisma.subject.upsert({
      where: { slug: subject.slug },
      update: {},
      create: {
        ...rest,
        examTypes: examTypes as ExamType[],
      },
    })
    createdSubjects[subject.slug] = created
    console.log(`✅ Subject created: ${subject.name}`)
  }

  // Create topics for each subject
  const createdTopics: Record<string, any> = {}
  for (const [subjectSlug, topicNames] of Object.entries(topicsPerSubject)) {
    const subject = createdSubjects[subjectSlug]
    if (!subject) continue

    for (let i = 0; i < topicNames.length; i++) {
      const topicName = topicNames[i]
      const topicSlug = topicName.toLowerCase().replace(/[^a-z0-9]+/g, '-')
      const topic = await prisma.topic.upsert({
        where: { subjectId_slug: { subjectId: subject.id, slug: topicSlug } },
        update: {},
        create: {
          subjectId: subject.id,
          name: topicName,
          slug: topicSlug,
          order: i,
        },
      })
      createdTopics[`${subjectSlug}:${topicSlug}`] = topic
    }
    console.log(`✅ Topics created for: ${subjectSlug}`)
  }

  // Helper to create a question with options
  async function createQuestion(subjectSlug: string, data: any) {
    const subject = createdSubjects[subjectSlug]
    if (!subject) return

    const topic = data.topicSlug ? createdTopics[`${subjectSlug}:${data.topicSlug}`] : null

    const question = await prisma.question.create({
      data: {
        subjectId: subject.id,
        topicId: topic?.id,
        text: data.text,
        explanation: data.explanation,
        difficulty: data.difficulty as Difficulty,
        examType: data.examType as ExamType,
        options: {
          create: data.options,
        },
      },
    })
    return question
  }

  // Seed math questions
  for (const q of mathQuestions) await createQuestion('mathematics', q)
  for (const q of bioQuestions) await createQuestion('biology', q)
  for (const q of chemQuestions) await createQuestion('chemistry', q)

  // Enroll demo student in core subjects
  const coreSubjects = ['mathematics', 'english', 'physics', 'chemistry', 'biology']
  for (const slug of coreSubjects) {
    const subject = createdSubjects[slug]
    if (!subject) continue
    await prisma.enrollment.upsert({
      where: { userId_subjectId: { userId: student.id, subjectId: subject.id } },
      update: {},
      create: { userId: student.id, subjectId: subject.id },
    })
  }
  console.log('✅ Demo student enrolled in core subjects')

  console.log('\n🎉 Seed completed successfully!')
  console.log('\nDemo Credentials:')
  console.log('Admin:   admin@studybuddy.ng / Admin@123')
  console.log('Student: student@studybuddy.ng / Student@123')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
