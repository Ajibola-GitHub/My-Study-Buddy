# 📚 My Study Buddy

> AI-powered exam prep for Nigerian secondary school students preparing for **WAEC**, **NECO**, and **JAMB**.

---

## 🗂️ Project Structure

```
my-study-buddy/
├── prisma/
│   ├── schema.prisma         # Full DB schema
│   └── seed.ts               # Seed with subjects, topics, sample questions
├── src/
│   ├── app/
│   │   ├── (auth)/           # Login, Signup, Forgot Password pages
│   │   ├── (student)/        # Dashboard, Subjects, Practice, AI Tutor, Profile
│   │   ├── (admin)/          # Admin Dashboard, Question/User Management
│   │   ├── api/              # All API routes
│   │   ├── layout.tsx        # Root layout
│   │   └── page.tsx          # Landing page
│   ├── components/
│   │   ├── ui/               # Button, Input, Card, Badge, Progress
│   │   ├── layout/           # Sidebar, MobileNav
│   │   ├── dashboard/        # StatsCard
│   │   ├── subjects/         # SubjectCard
│   │   ├── practice/         # QuestionCard
│   │   └── ai/               # ChatInterface
│   ├── lib/
│   │   ├── auth.ts           # NextAuth v5 config
│   │   ├── db.ts             # Prisma client
│   │   ├── email.ts          # Nodemailer
│   │   ├── openai.ts         # OpenAI + system prompt
│   │   └── utils.ts          # Helpers
│   ├── types/                # TypeScript types
│   └── middleware.ts         # Route protection
├── .env.example              # Environment variable template
├── package.json
└── tailwind.config.ts
```

---

## ⚙️ Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 18+ | https://nodejs.org |
| npm | 9+ | Comes with Node |
| PostgreSQL | 14+ | https://www.postgresql.org or use Neon (free) |
| Git | Any | https://git-scm.com |

---

## 🚀 Local Development Setup

### Step 1 — Clone and install dependencies

```bash
# Clone the repo
git clone <your-repo-url>
cd my-study-buddy

# Install all packages
npm install
```

### Step 2 — Configure environment variables

```bash
# Copy the example env file
cp .env.example .env.local

# Open .env.local and fill in ALL values
nano .env.local   # or use VS Code: code .env.local
```

**Required variables to fill:**

```env
# PostgreSQL — use Neon.tech (free) or local Postgres
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/study_buddy"

# Generate a random secret:  openssl rand -base64 32
AUTH_SECRET="paste-your-generated-secret-here"
NEXTAUTH_URL="http://localhost:3000"

# OpenAI — get from platform.openai.com
OPENAI_API_KEY="sk-..."

# Cloudinary — free at cloudinary.com (for image uploads)
CLOUDINARY_CLOUD_NAME="your-cloud-name"
CLOUDINARY_API_KEY="your-api-key"
CLOUDINARY_API_SECRET="your-api-secret"
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME="your-cloud-name"

# Email — use Gmail App Password (optional, for password reset)
EMAIL_HOST="smtp.gmail.com"
EMAIL_PORT="587"
EMAIL_USER="your@gmail.com"
EMAIL_PASS="your-app-password"
EMAIL_FROM="My Study Buddy <your@gmail.com>"

NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

### Step 3 — Set up the database

```bash
# Push schema to database (creates all tables)
npx prisma db push

# Generate Prisma client
npx prisma generate

# Seed with subjects, topics, and sample questions
npx ts-node prisma/seed.ts
```

### Step 4 — Run the development server

```bash
npm run dev
```

Open **http://localhost:3000** in your browser 🎉

---

## 🧪 Test Accounts (after seeding)

| Role | Email | Password |
|------|-------|----------|
| Student | student@studybuddy.ng | Student@123 |
| Admin | admin@studybuddy.ng | Admin@123 |

---

## 📱 Pages to Test

| URL | Description |
|-----|-------------|
| `/` | Landing page |
| `/signup` | Create new account |
| `/login` | Sign in |
| `/dashboard` | Student dashboard with stats |
| `/subjects` | Browse & enroll in subjects |
| `/practice` | Practice session with MCQs |
| `/ai-tutor` | Chat with AI tutor |
| `/profile` | Update profile settings |
| `/admin/dashboard` | Admin overview (admin only) |
| `/admin/questions` | Question bank management |

---

## 🗄️ Database Management

```bash
# View database in browser UI
npx prisma studio

# Reset and re-seed (CAUTION: deletes all data)
npx prisma db push --force-reset
npx ts-node prisma/seed.ts

# Create a migration (for production changes)
npx prisma migrate dev --name "your-migration-name"
```

---

## 🌐 Free Database Options (No Local Postgres Needed)

### Option 1 — Neon (Recommended, fully free)
1. Go to **https://neon.tech** and sign up free
2. Create a new project → copy the connection string
3. Paste into `DATABASE_URL` in `.env.local`

### Option 2 — Supabase (free tier)
1. Go to **https://supabase.com** and create project
2. Settings → Database → copy the URI connection string
3. Paste into `DATABASE_URL`

### Option 3 — Railway
1. **https://railway.app** → New Project → PostgreSQL
2. Copy the DATABASE_URL from the variables tab

---

## ☁️ Deployment to Vercel (Production)

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit - My Study Buddy MVP"
git remote add origin https://github.com/your-username/study-buddy.git
git push -u origin main
```

### Step 2 — Deploy to Vercel

1. Go to **https://vercel.com** → New Project
2. Import your GitHub repository
3. Framework preset: **Next.js** (auto-detected)
4. Add all environment variables from `.env.local` (Settings → Environment Variables)
5. Change `NEXTAUTH_URL` to your Vercel URL: `https://your-project.vercel.app`
6. Change `NEXT_PUBLIC_APP_URL` to the same Vercel URL
7. Click **Deploy** 🚀

### Step 3 — Run migrations on production

```bash
# Set production DATABASE_URL, then:
npx prisma migrate deploy
npx ts-node prisma/seed.ts  # seed initial data
```

---

## 🔧 Alternative Deployments

### Netlify
Netlify works but requires some config since this is Next.js:
```bash
npm install -D @netlify/plugin-nextjs
```
Add `netlify.toml`:
```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

### Railway (Full-stack — app + DB on same platform)
1. New Project → Deploy from GitHub
2. Add PostgreSQL service
3. Add all environment variables
4. Deploy — Railway auto-detects Next.js

---

## 📊 Key Features Summary

| Feature | Status | Notes |
|---------|--------|-------|
| Registration/Login | ✅ | Email + password with bcrypt |
| Password Reset | ✅ | Email token (requires EMAIL_* env vars) |
| Dashboard | ✅ | Stats, charts, recent activity |
| Subject Library | ✅ | 10 subjects, enroll/unenroll |
| Practice Questions | ✅ | MCQ with instant feedback + explanation |
| AI Tutor | ✅ | GPT-4o powered, chat history stored |
| Performance Tracking | ✅ | Per-subject accuracy, weekly chart |
| Study Streaks | ✅ | Auto-tracked on each practice |
| Admin Dashboard | ✅ | Stats, user list, question table |
| Mobile Responsive | ✅ | Bottom nav on mobile |
| Image Upload | ⚙️ | Cloudinary (requires credentials) |

---

## 🆘 Troubleshooting

**"Cannot find module '@prisma/client'"**
```bash
npx prisma generate
```

**"Database connection failed"**
- Check your `DATABASE_URL` in `.env.local`
- Make sure PostgreSQL is running (or use Neon/Supabase)
- Test the URL: `npx prisma db pull`

**"OpenAI API error"**
- Check your `OPENAI_API_KEY` is valid
- Ensure you have credits on your OpenAI account
- AI Tutor will show an error message if the key is missing/invalid

**Page redirects to login unexpectedly**
- Make sure `AUTH_SECRET` is set in `.env.local`
- Ensure `NEXTAUTH_URL=http://localhost:3000` for local dev

**Build fails on Vercel**
- Check all environment variables are set in Vercel dashboard
- Update `NEXTAUTH_URL` to your actual Vercel deployment URL

---

## 📞 Stack Reference

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Database | PostgreSQL + Prisma ORM |
| Authentication | NextAuth v5 / Auth.js |
| AI | OpenAI GPT-4o |
| Email | Nodemailer |
| Images | Cloudinary |
| Deployment | Vercel (recommended) |

---

*Built for Nigerian secondary school students. 🇳🇬 Empowering the next generation.*
